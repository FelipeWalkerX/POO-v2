#include "Entidades.h"
#include "Sistemas.h"

// --------- IMPLEMENTACAO DAS HABILIDADES (usar) ------------
// Ficam aqui pois usam Logger::instancia() (definido em Sistemas.h)

bool BolaDeFogo::usar(shared_ptr<Jogador> usuario, shared_ptr<Inimigo> alvo){
    if (usuario->mana < this->getCustoMana()){
        return false;
    }
    usuario->mana -= this->getCustoMana();
    int danoCausado = 35 + usuario->getLevel() * 2;
    cout << usuario->getNome() << " conjurou " << this->getNome() << " em " << alvo->getNome() << "!" << endl;
    alvo->receberDano(danoCausado, usuario);
    Logger::instancia().log(usuario->getNome() + " usou " + this->getNome() + " em " + alvo->getNome());
    return true;
}

bool GolpeFurtivo::usar(shared_ptr<Jogador> usuario, shared_ptr<Inimigo> alvo){
    if (usuario->mana < this->getCustoMana()){
        return false;
    }
    usuario->mana -= this->getCustoMana();
    int danoCausado = 25 + usuario->furtividade;
    cout << usuario->getNome() << " usou " << this->getNome() << " em " << alvo->getNome() << "!" << endl;
    alvo->receberDano(danoCausado, usuario);
    Logger::instancia().log(usuario->getNome() + " usou " + this->getNome() + " em " + alvo->getNome());
    return true;
}

bool GranadaImprovisada::usar(shared_ptr<Jogador> usuario, shared_ptr<Inimigo> alvo){
    if (usuario->mana < this->getCustoMana()){
        return false;
    }
    usuario->mana -= this->getCustoMana();
    int danoCausado = 30;
    cout << usuario->getNome() << " jogou uma " << this->getNome() << " em " << alvo->getNome() << "!" << endl;
    alvo->receberDano(danoCausado, usuario);
    Logger::instancia().log(usuario->getNome() + " usou " + this->getNome() + " em " + alvo->getNome());
    return true;
}

// Implementacao de GolpeBrutal fica aqui pois precisa do atributo forca, que e exclusivo do Guerreiro
bool GolpeBrutal::usar(shared_ptr<Jogador> usuario, shared_ptr<Inimigo> alvo){
    if (usuario->mana < this->getCustoMana()){
        return false;
    }
    shared_ptr<Guerreiro> guerreiro = dynamic_pointer_cast<Guerreiro>(usuario);
    int bonusForca = (guerreiro != nullptr) ? guerreiro->forca : 0;
    usuario->mana -= this->getCustoMana();
    int danoCausado = 20 + bonusForca;
    cout << usuario->getNome() << " desferiu um " << this->getNome() << " em " << alvo->getNome() << "!" << endl;
    alvo->receberDano(danoCausado, usuario);
    Logger::instancia().log(usuario->getNome() + " usou " + this->getNome() + " em " + alvo->getNome());
    return true;
}

// --------- IMPLEMENTACAO DAS ESTRATEGIAS DE ATAQUE (Strategy) ------------
// A logica abaixo e a mesma que existia dentro de cada atacar(), so que agora separada por estrategia
// em vez de estar duplicada dentro de cada classe de Jogador. Usa dynamic_pointer_cast para saber
// qual classe concreta esta atacando, ja que cada uma calcula o dano com um atributo diferente

int AtaqueComArma::executar(shared_ptr<Jogador> atacante, shared_ptr<Jogador> alvo){
    if (alvo->morto){
        cout << alvo->getNome() << " ja esta morto!" << endl;
        return 0;
    }

    shared_ptr<Ladrao> ladrao = dynamic_pointer_cast<Ladrao>(atacante);
    shared_ptr<Artifice> artifice = dynamic_pointer_cast<Artifice>(atacante);
    shared_ptr<Guerreiro> guerreiro = dynamic_pointer_cast<Guerreiro>(atacante);

    if (ladrao != nullptr){
        int roll = randint(1, 20);
        if (alvo->getArmadura() > roll){
            cout << "A armadura de " << alvo->getNome() << " absorveu todo dano" << endl;
        }
        if (roll == 20){
            alvo->receberDano(ladrao->dano * 4);
            Logger::instancia().log("SUCESSO CRITICO!!! " + ladrao->getNome() + " deu " + to_string(ladrao->agilidade * 4) + " de dano em " + alvo->getNome());
        }
        else if (roll == 1){
            Logger::instancia().log(ladrao->getNome() + " errou o ataque em " + alvo->getNome());
            return 0;
        }
        else if (roll > 12){
            alvo->receberDano(ladrao->agilidade * 2);
            Logger::instancia().log(ladrao->getNome() + " critou e deu " + to_string(ladrao->dano * 2) + " de dano em " + alvo->getNome());
        }
        else{
            alvo->receberDano(ladrao->agilidade);
            Logger::instancia().log(ladrao->getNome() + " deu " + to_string(ladrao->dano) + " de dano em " + alvo->getNome());
        }
    }
    else if (artifice != nullptr){
        if (artifice->mana >= 10){
            artifice->mana -= 10;
            int roll = randint(1, 20);
            if (alvo->getArmadura() > roll){
                cout << "A armadura de " << alvo->getNome() << " absorveu todo dano" << endl;
            }
            if (roll == 20){
                alvo->receberDano(artifice->inteligencia * 2);
                Logger::instancia().log(artifice->getNome() + " critou e deu " + to_string(artifice->inteligencia * 2) + " de dano em " + alvo->getNome());
            }
            else if (roll == 1){
                Logger::instancia().log(artifice->getNome() + " errou o ataque em " + alvo->getNome());
            }
            else{
                alvo->receberDano(artifice->inteligencia);
                Logger::instancia().log(artifice->getNome() + " deu " + to_string(artifice->inteligencia) + " de dano em " + alvo->getNome());
            }
        }
        else{
            cout << artifice->getNome() << " nao tem mais mana! Mana restante: " << artifice->mana << endl;
        }
    }
    else if (guerreiro != nullptr){
        int roll = randint(1, 20);
        if (alvo->getArmadura() > roll){
            cout << "A armadura de " << alvo->getNome() << " absorveu todo dano" << endl;
        }
        if (roll == 20){
            alvo->receberDano(guerreiro->forca * 2);
            cout << "SUCESSO CRITICO" << endl;
            Logger::instancia().log(guerreiro->getNome() + " deu " + to_string(guerreiro->forca * 2) + " de dano em " + alvo->getNome());
        }
        else if (roll == 1){
            Logger::instancia().log(guerreiro->getNome() + " errou o ataque em " + alvo->getNome());
            return 0;
        }
        else{
            alvo->receberDano(guerreiro->forca);
            Logger::instancia().log(guerreiro->getNome() + " deu " + to_string(guerreiro->forca) + " de dano em " + alvo->getNome());
        }
    }

    if (alvo->morto){
        cout << alvo->getNome() << " morreu!\n" << endl;
    }
    else{
        cout << alvo->getNome() << ": " << alvo->getHP() << "/" << alvo->getHPMax() << "\n" << endl;
    }
    return 0;
}

int AtaqueComArma::executar(shared_ptr<Jogador> atacante, shared_ptr<Inimigo> alvo){
    if (alvo->morto){
        cout << alvo->getNome() << " ja esta morto!" << endl;
        return 0;
    }

    shared_ptr<Ladrao> ladrao = dynamic_pointer_cast<Ladrao>(atacante);
    shared_ptr<Artifice> artifice = dynamic_pointer_cast<Artifice>(atacante);
    shared_ptr<Guerreiro> guerreiro = dynamic_pointer_cast<Guerreiro>(atacante);

    if (ladrao != nullptr){
        int roll = randint(1, 20);
        if (alvo->getArmadura() > roll){
            cout << "A armadura de " << alvo->getNome() << " absorveu todo dano" << endl;
        }
        if (roll == 20){
            alvo->receberDano(ladrao->dano * 4, ladrao);
            Logger::instancia().log("SUCESSO CRITICO!!! " + ladrao->getNome() + " deu " + to_string(ladrao->agilidade * 4) + " de dano em " + alvo->getNome());
        }
        else if (roll == 1){
            Logger::instancia().log(ladrao->getNome() + " errou o ataque em " + alvo->getNome());
            return 0;
        }
        else if (roll > 12){
            alvo->receberDano(ladrao->agilidade * 2, ladrao);
            Logger::instancia().log(ladrao->getNome() + " critou e deu " + to_string(ladrao->dano * 2) + " de dano em " + alvo->getNome());
        }
        else{
            alvo->receberDano(ladrao->agilidade, ladrao);
            Logger::instancia().log(ladrao->getNome() + " deu " + to_string(ladrao->dano) + " de dano em " + alvo->getNome());
        }
    }
    else if (artifice != nullptr){
        if (artifice->mana >= 10){
            artifice->mana -= 10;
            int roll = randint(1, 20);
            if (alvo->getArmadura() > roll){
                cout << "A armadura de " << alvo->getNome() << " absorveu todo dano" << endl;
            }
            if (roll == 20){
                alvo->receberDano(artifice->inteligencia * 2, artifice);
                Logger::instancia().log(artifice->getNome() + " critou e deu " + to_string(artifice->inteligencia * 2) + " de dano em " + alvo->getNome());
            }
            else if (roll == 1){
                Logger::instancia().log(artifice->getNome() + " errou o ataque em " + alvo->getNome());
            }
            else{
                alvo->receberDano(artifice->inteligencia, artifice);
                Logger::instancia().log(artifice->getNome() + " deu " + to_string(artifice->inteligencia) + " de dano em " + alvo->getNome());
            }
        }
        else{
            cout << artifice->getNome() << " nao tem mais mana! Mana restante: " << artifice->mana << endl;
        }
    }
    else if (guerreiro != nullptr){
        int roll = randint(1, 20);
        if (alvo->getArmadura() > roll){
            cout << "A armadura de " << alvo->getNome() << " absorveu todo dano" << endl;
        }
        if (roll == 20){
            alvo->receberDano(guerreiro->forca * 2, guerreiro);
            cout << "SUCESSO CRITICO" << endl;
            Logger::instancia().log(guerreiro->getNome() + " deu " + to_string(guerreiro->forca * 2) + " de dano em " + alvo->getNome());
        }
        else if (roll == 1){
            Logger::instancia().log(guerreiro->getNome() + " errou o ataque em " + alvo->getNome());
            return 0;
        }
        else{
            alvo->receberDano(guerreiro->forca, guerreiro);
            Logger::instancia().log(guerreiro->getNome() + " deu " + to_string(guerreiro->forca) + " de dano em " + alvo->getNome());
        }
    }

    if (alvo->morto){
        cout << alvo->getNome() << " morreu!\n" << endl;
    }
    else{
        cout << alvo->getNome() << ": " << alvo->getHP() << "/" << alvo->getHPMax() << "\n" << endl;
    }
    return 0;
}

// AtaqueDesarmado: murro/tapa, ou pedra do Artifice quando ela existir no inventario
int AtaqueDesarmado::executar(shared_ptr<Jogador> atacante, shared_ptr<Jogador> alvo){
    shared_ptr<Artifice> artifice = dynamic_pointer_cast<Artifice>(atacante);
    shared_ptr<Guerreiro> guerreiro = dynamic_pointer_cast<Guerreiro>(atacante);

    if (artifice != nullptr){
        try{
            shared_ptr<Item> pedra = artifice->inventario.buscarItens("Pedra Inutil");
            pedra->quantidade -= 1;
            if (pedra->quantidade < 1){
                artifice->inventario.removerItem("Pedra Inutil");
            }
            alvo->receberDano(10);
            Logger::instancia().log(artifice->getNome() + " tacou uma pedra em " + alvo->getNome());
        }
        catch (...){
            alvo->receberDano(5);
            Logger::instancia().log(artifice->getNome() + " deu um tapa em " + alvo->getNome());
            return 5;
        }
        return 0;
    }
    else if (guerreiro != nullptr){
        cout << guerreiro->getNome() << " estava sem arma equipada para atacar" << endl;
        alvo->receberDano(20);
        Logger::instancia().log(guerreiro->getNome() + " deu um murro em " + alvo->getNome());
        return 20;
    }
    else{
        cout << atacante->getNome() << " estava sem arma equipada para atacar" << endl;
        alvo->receberDano(10);
        Logger::instancia().log(atacante->getNome() + " deu um tapa em " + alvo->getNome());
        return 10;
    }
}

int AtaqueDesarmado::executar(shared_ptr<Jogador> atacante, shared_ptr<Inimigo> alvo){
    shared_ptr<Artifice> artifice = dynamic_pointer_cast<Artifice>(atacante);
    shared_ptr<Guerreiro> guerreiro = dynamic_pointer_cast<Guerreiro>(atacante);

    if (artifice != nullptr){
        try{
            shared_ptr<Item> pedra = artifice->inventario.buscarItens("Pedra Inutil");
            pedra->quantidade -= 1;
            if (pedra->quantidade < 1){
                artifice->inventario.removerItem("Pedra Inutil");
            }
            alvo->receberDano(10, artifice);
            Logger::instancia().log(artifice->getNome() + " tacou uma pedra em " + alvo->getNome());
        }
        catch (...){
            alvo->receberDano(5, artifice);
            Logger::instancia().log(artifice->getNome() + " deu um tapa em " + alvo->getNome());
            return 5;
        }
        return 0;
    }
    else if (guerreiro != nullptr){
        cout << guerreiro->getNome() << " estava sem arma equipada para atacar" << endl;
        alvo->receberDano(20, guerreiro);
        Logger::instancia().log(guerreiro->getNome() + " deu um murro em " + alvo->getNome());
        return 20;
    }
    else{
        cout << atacante->getNome() << " estava sem arma equipada para atacar" << endl;
        alvo->receberDano(10, atacante);
        Logger::instancia().log(atacante->getNome() + " deu um tapa em " + alvo->getNome());
        return 10;
    }
}

// -------------- IMPLEMENTACAO: ATAQUES DAS CLASSES DE JOGADOR --------------------
// Cada classe tem duas versoes de atacar(): uma contra Jogador e outra contra Inimigo
// O sistema de rolagem usa d20 (dado de 20 faces): 20 = critico, 1 = falha critica, resto = normal

int Bruxo::atacar(shared_ptr<Jogador> alvo){
    cout << this->getNome() << " vai atacar " << alvo->getNome() << ":" << endl;
    if (alvo->morto){
        cout << alvo->getNome() << " ja esta morto!" << endl;
        return 0;
    }

    if (this->mana >= 10){
        this->mana -= 10;
        int roll = randint(1, 20);

        if (alvo->getArmadura() > roll){
            cout << "A armadura de " << alvo->getNome() << " absorveu todo dano" << endl;
        }

        if (roll == 20){
            alvo->receberDano(this->carisma * 2);
            Logger::instancia().log(this->getNome() + " critou e deu " + to_string(this->carisma * 2) + " de dano em " + alvo->getNome());
        }
        else if (roll == 1){
            Logger::instancia().log(this->getNome() + " errou o ataque em " + alvo->getNome());
            return 0;
        }
        else{
            alvo->receberDano(this->carisma);
            Logger::instancia().log(this->getNome() + " deu " + to_string(this->carisma) + " de dano em " + alvo->getNome());
        }

        if (alvo->morto){
            cout << alvo->getNome() << " morreu!\n" << endl;
        }
        else{
            cout << alvo->getNome() << ": " << alvo->getHP() << "/" << alvo->getHPMax() << "\n" << endl;
        }
    }
    else{
        throw AcaoInvalidaException(this->getNome() + " nao tem mais mana! Mana restante: " + to_string(this->mana));
    }
    return 0;
}

int Bruxo::atacar(shared_ptr<Inimigo> alvo){
    cout << this->getNome() << " vai atacar " << alvo->getNome() << ":" << endl;
    if (alvo->morto){
        cout << alvo->getNome() << " ja esta morto!" << endl;
        return 0;
    }

    if (this->mana >= 10){
        this->mana -= 10;
        int roll = randint(1, 20);

        if (alvo->getArmadura() > roll){
            cout << "A armadura de " << alvo->getNome() << " absorveu todo dano" << endl;
        }

        if (roll == 20){
            alvo->receberDano(this->carisma * 2, dynamic_pointer_cast<Jogador>(shared_from_this()));
            Logger::instancia().log(this->getNome() + " critou e deu " + to_string(this->carisma * 2) + " de dano em " + alvo->getNome());
        }
        else if (roll == 1){
            Logger::instancia().log(this->getNome() + " errou o ataque em " + alvo->getNome());
            return 0;
        }
        else{
            alvo->receberDano(this->carisma, dynamic_pointer_cast<Jogador>(shared_from_this()));
            Logger::instancia().log(this->getNome() + " deu " + to_string(this->carisma) + " de dano em " + alvo->getNome());
        }

        if (alvo->morto){
            cout << alvo->getNome() << " morreu!\n" << endl;
        }
        else{
            cout << alvo->getNome() << ": " << alvo->getHP() << "/" << alvo->getHPMax() << "\n" << endl;
        }
    }
    else{
        throw AcaoInvalidaException(this->getNome() + " nao tem mais mana! Mana restante: " + to_string(this->mana));
    }
    return 0;
}

int Ladrao::atacar(shared_ptr<Jogador> alvo){
    cout << this->getNome() << " vai atacar " << alvo->getNome() << ":" << endl;
    // O if (armaEquipada) {...} else {...} que existia aqui foi extraido para o Strategy:
    // this->estrategiaAtaque ja decide certo entre AtaqueComArma e AtaqueDesarmado
    return this->estrategiaAtaque->executar(dynamic_pointer_cast<Jogador>(shared_from_this()), alvo);
}

int Ladrao::atacar(shared_ptr<Inimigo> alvo){
    cout << this->getNome() << " vai atacar " << alvo->getNome() << ":" << endl;
    return this->estrategiaAtaque->executar(dynamic_pointer_cast<Jogador>(shared_from_this()), alvo);
}

int Artifice::atacar(shared_ptr<Jogador> alvo){
    cout << this->getNome() << " vai atacar " << alvo->getNome() << ":" << endl;
    return this->estrategiaAtaque->executar(dynamic_pointer_cast<Jogador>(shared_from_this()), alvo);
}

int Artifice::atacar(shared_ptr<Inimigo> alvo){
    cout << this->getNome() << " vai atacar " << alvo->getNome() << ":" << endl;
    return this->estrategiaAtaque->executar(dynamic_pointer_cast<Jogador>(shared_from_this()), alvo);
}

int Guerreiro::atacar(shared_ptr<Jogador> alvo){
    cout << this->getNome() << " vai atacar " << alvo->getNome() << ":" << endl;
    return this->estrategiaAtaque->executar(dynamic_pointer_cast<Jogador>(shared_from_this()), alvo);
}

int Guerreiro::atacar(shared_ptr<Inimigo> alvo){
    cout << this->getNome() << " vai atacar " << alvo->getNome() << ":" << endl;
    return this->estrategiaAtaque->executar(dynamic_pointer_cast<Jogador>(shared_from_this()), alvo);
}

// ------------------- IMPLEMENTACAO: ATAQUES DOS INIMIGOS -----------------

int Dragao::atacar(shared_ptr<Jogador> alvo){
    cout << this->getNome() << " vai atacar " << alvo->getNome() << ":" << endl;
    if (alvo->morto){
        cout << alvo->getNome() << " ja esta morto!" << endl;
        return 0;
    }
    int roll = randint(1, 20);
    if (roll == 1){
        Logger::instancia().log(this->getNome() + " falhou miseravelmente no seu ataque");
        return 0;
    }
    alvo->receberDano(this->dano);
    Logger::instancia().log(this->getNome() + " soltou o bafo do selvagem no " + alvo->getNome() + " e deu " + to_string(this->dano) + " de dano");
    if (alvo->morto){
        cout << alvo->getNome() << " virou carvao!\n" << endl;
    }
    else{
        cout << alvo->getNome() << ": " << alvo->getHP() << "/" << alvo->getHPMax() << "\n" << endl;
    }
    return 0;
}

int Basilisco::atacar(shared_ptr<Jogador> alvo){
    cout << this->getNome() << " vai atacar " << alvo->getNome() << ":" << endl;
    if (alvo->morto){
        cout << alvo->getNome() << " ja esta morto!" << endl;
        return 0;
    }
    int roll = randint(1, 20);
    if (roll == 1){
        Logger::instancia().log(this->getNome() + " falhou miseravelmente no seu ataque");
        return 0;
    }
    alvo->receberDano(this->dano);
    Logger::instancia().log(this->getNome() + " mordeu " + alvo->getNome() + " e deu " + to_string(this->dano) + " de dano");
    if (alvo->morto){
        cout << alvo->getNome() << " foi engolido pelo " << this->getNome() << "!\n" << endl;
    }
    else{
        cout << alvo->getNome() << ": " << alvo->getHP() << "/" << alvo->getHPMax() << "\n" << endl;
    }
    return 0;
}

int Saqueadores::atacar(shared_ptr<Jogador> alvo){
    cout << this->getNome() << " vai atacar " << alvo->getNome() << ":" << endl;
    if (alvo->morto){
        cout << alvo->getNome() << " ja esta morto!" << endl;
        return 0;
    }
    int roll = randint(1, 20);
    if (roll == 1){
        Logger::instancia().log(this->getNome() + " falhou miseravelmente no seu ataque");
        return 0;
    }
    alvo->receberDano(this->dano * 2); // Sao dois saqueadores que atacam ao mesmo tempo
    Logger::instancia().log(this->getNome() + " esfaquearam o bucho do " + alvo->getNome() + " e deram " + to_string(this->dano * 2) + " de dano");
    if (alvo->morto){
        cout << alvo->getNome() << " virou estatistica!\n" << endl;
    }
    else{
        cout << alvo->getNome() << ": " << alvo->getHP() << "/" << alvo->getHPMax() << "\n" << endl;
    }
    return 0;
}

// --------------- OUTRAS IMPLEMENTACOES DE JOGADOR/INIMIGO ---------------

// Adiciona XP ao jogador e, se atingir o maximo, sobe de nivel (com repeticao caso suba mais de um nivel)
// Tambem registra o XP e nivel no GerenciadorDeJogo para controle global
bool Jogador::ganharXP(int experiencia){
    if (this->morto == true){
        cout << this->getNome() << " morreu e nao pode ganhar xp!\n" << endl;
        return false;
    }
    this->xp += experiencia;
    GerenciadorDeJogo &gerenciadorJogo = GerenciadorDeJogo::instancia();
    gerenciadorJogo.adicionarXP(experiencia);
    while (this->xp >= this->xpMax){
        this->setLevel(this->getLevel() + 1);
        this->xp -= this->xpMax;
        gerenciadorJogo.subirNivel();
    }
    cout << this->getNome() << " subiu para o nivel " << this->getLevel() << endl;
    return true;
}

map<string, string> Jogador::serializaDicionario(){
    return {{"nome", this->getNome()},
            {"level", to_string(this->getLevel())},
            {"hp", to_string(this->getHP())},
            {"hpMax", to_string(this->getHPMax())},
            {"xp", to_string(this->xp)},
            {"Raca", this->raca->nomeClasse()},
            {"classe", this->nomeClasse()},
            {"versao", "1.0"}};
}

shared_ptr<Jogador> Jogador::desserializaDicionario(const map<string, string> &dados){
    map<string, shared_ptr<Raca>> Racas = {{"MeioElfo", make_shared<MeioElfo>()},
                                           {"Humano", make_shared<Humano>()},
                                           {"Tiefling", make_shared<Tiefling>()}};
    shared_ptr<Raca> racaObj = Racas.count(dados.at("Raca")) ? Racas[dados.at("Raca")] : make_shared<Humano>();

    string classe = dados.at("classe");
    shared_ptr<Jogador> j = nullptr;
    if (classe == "Bruxo")
        j = make_shared<Bruxo>(dados.at("nome"), stoi(dados.at("level")), racaObj, stoi(dados.at("hp")), stoi(dados.at("xp")));
    else if (classe == "Ladrao")
        j = make_shared<Ladrao>(dados.at("nome"), stoi(dados.at("level")), racaObj, stoi(dados.at("hp")), stoi(dados.at("xp")));
    else if (classe == "Artifice")
        j = make_shared<Artifice>(dados.at("nome"), stoi(dados.at("level")), racaObj, stoi(dados.at("hp")), stoi(dados.at("xp")));
    else if (classe == "Guerreiro")
        j = make_shared<Guerreiro>(dados.at("nome"), stoi(dados.at("level")), racaObj, stoi(dados.at("hp")), stoi(dados.at("xp")));

    return j;
}

// Sobrecarga do operador << para exibir jogadores diretamente com cout
ostream &operator<<(ostream &os, const shared_ptr<Jogador> &jogador){
    if (jogador != nullptr)
        os << jogador->str();
    else
        os << "None";
    return os;
}

// Funcao que ativa caso o inimigo morra, liberando recompensas para o jogador que deu o ultimo hit
void Inimigo::droparRecompensas(shared_ptr<Jogador> jogador){
    if (this->morto){
        jogador->ganharXP(this->xpRecompensa);
        GerenciadorDeJogo::instancia().adicionarOuro(this->ouroRecompensa);
        cout << jogador->getNome() << " ganhou " << this->xpRecompensa << " de XP e " << this->ouroRecompensa << " de grana!" << endl;
    }
}
