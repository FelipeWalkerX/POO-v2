#ifndef SISTEMAS_H
#define SISTEMAS_H

#include <iostream>
#include <string>
#include <vector>
#include <map>
#include <memory>
#include <functional>
#include <algorithm>
#include <fstream>
#include <sstream>
#include <regex>
#include "Excecoes.h"
#include "Itens.h"
#include "Entidades.h"
#include "Utils.h"
using namespace std;

// -------------- CLASSE LOGGER (SINGLETON) -----------------
// Registra e exibe mensagens de log de toda a partida
// Implementado como Singleton: so existe uma instancia em todo o jogo,
// garantindo que todos os eventos sejam registrados no mesmo lugar
class Logger{
private:
    static Logger *_instancia;
    bool _inicializado;

    Logger(){
        _inicializado = false;
        if (this->_inicializado){
            return;
        }
        this->logs = {};
        this->_inicializado = true;
    }

public:
    vector<string> logs;

    static Logger &instancia(){
        if (_instancia == nullptr){
            _instancia = new Logger();
        }
        return *_instancia;
    }

    void registrarMensagem(string msg){
        this->logs.push_back(msg);
    }

    void exibirLogs(){
        for (string log : this->logs){
            cout << log << endl;
        }
    }

    void log(string msg){
        cout << msg << endl;
        this->logs.push_back(msg);
    }
};

// --------------- SINGLETON: GERENCIADOR DE JOGO -------------------
// Centraliza o estado global da partida: ouro do grupo, XP acumulado, nivel, lista de jogadores e inimigos
// e mapa de estado (quais inimigos foram derrotados, quantos itens foram comprados/vendidos)
// Implementado como Singleton: garante que todas as classes (Masmorra, Mercadao, QuadroMissoes)
// leem e escrevem no mesmo objeto
class GerenciadorDeJogo{
private:
    static GerenciadorDeJogo *_instancia;
    bool _inicializado;

    GerenciadorDeJogo(){
        _inicializado = false;
        if (this->_inicializado){
            return;
        }
        this->nivel = 1;
        this->ouro = 0;
        this->xp = 0;
        this->estado = {{"dragaoMorto", false},
                        {"basiliscoMorto", false},
                        {"saqueadores", false},
                        {"itensVendidos", 0},
                        {"itensComprados", 0}};
        this->_inicializado = true;
    }

public:
    int nivel;
    int ouro;
    int xp;
    map<string, int> estado;
    vector<shared_ptr<Jogador>> jogadores;
    vector<shared_ptr<Inimigo>> inimigos;

    static GerenciadorDeJogo &instancia(){
        if (_instancia == nullptr){
            _instancia = new GerenciadorDeJogo();
        }
        return *_instancia;
    }

    void adicionarOuro(int quantidade){
        this->ouro += quantidade;
    }

    void comprarItem(shared_ptr<Item> item){
        if (this->ouro < item->valor){
            throw SemDinheiroException("Ta liso paizao? Tu so tem " + to_string(this->ouro) + " e a " + item->nomeItem + " custa " + to_string(item->valor));
        }
        this->ouro -= item->valor;
    }

    void adicionarXP(int xp){
        this->xp += xp;
    }

    void subirNivel(){
        this->nivel += 1;
    }

    void exibir(){
        cout << "[Gerenciador]: nivel = " << this->nivel << " "
             << "ouro  = " << this->ouro << " "
             << "xp = " << this->xp << endl;
    }

    void adicionarJogador(shared_ptr<Jogador> jogador){
        if (this->jogadores.size() > 5){
            throw LimiteJogadoresException("Quantidade de jogadores limite atingida!!! Total " + to_string(this->jogadores.size()) + "/5");
        }
        this->jogadores.push_back(jogador);
        cout << jogador->getNome() << " adicionado. Total de jogadores: " << this->jogadores.size() << endl;
    }

    void adicionarInimigos(shared_ptr<Inimigo> inimigo){
        this->inimigos.push_back(inimigo);
        cout << inimigo->getNome() << " adicionado. Total de inimigos: " << this->inimigos.size() << endl;
    }
};

// ------------ FACTORY: CRIACAO DE ITENS -----------------
// Padrao de projeto Factory: centraliza a criacao de armas, armaduras e pocoes
class CriacaoItens{
public:
    static shared_ptr<Arma> criarArma(string tipo){
        map<string, shared_ptr<Arma>> armas = {{"espada", make_shared<Arma>("Dualiso", 200, 2, 25)},
                                               {"machado", make_shared<Arma>("Machadinha Infernal", 300, 2, 40)},
                                               {"adaga", make_shared<Arma>("Lamina Oculta", 150, 1, 20)},
                                               {"rapiera", make_shared<Arma>("Maellum", 500, 2, 35)},
                                               {"foco arcano", make_shared<Arma>("Trebuchim", 300, 1, 20)},
                                               {"foice", make_shared<Arma>("Moisson", 400, 3, 25)}};
        if (armas.count(tipo))
            return armas[tipo];
        return nullptr;
    }

    static shared_ptr<Armadura> criarArmaduras(string tipo){
        map<string, shared_ptr<Armadura>> armaduras = {{"malha", make_shared<Armadura>("Cota de Malha", 100, 2, 3)},
                                                       {"couro", make_shared<Armadura>("Armadura de Couro", 150, 2, 5)},
                                                       {"ferro", make_shared<Armadura>("Armadura de Ferro", 400, 3, 10)}};
        if (armaduras.count(tipo))
            return armaduras[tipo];
        return nullptr;
    }

    static shared_ptr<Consumiveis> criarPocao(string tipo, int quantidade = 1){
        map<string, shared_ptr<Consumiveis>> pocoes = {{"vida", make_shared<PocaoVida>(quantidade)},
                                                       {"mana", make_shared<PocaoMana>(quantidade)},
                                                       {"fogo", make_shared<DanoFogo>(quantidade)},
                                                       {"gelo", make_shared<DanoGelo>(quantidade)},
                                                       {"relampago", make_shared<DanoRelampago>(quantidade)},
                                                       {"radiante", make_shared<DanoRadiante>(quantidade)},
                                                       {"venenoso", make_shared<DanoVenenoso>(quantidade)}};
        if (pocoes.count(tipo))
            return pocoes[tipo];
        return nullptr;
    }
};

// Factory para jogadores: recebe classe, nome, nivel e raca e retorna o objeto polimorfico correto
class CriacaoJogadores{
public:
    static shared_ptr<Jogador> criarJogadores(string classe, string nome, int nivel, shared_ptr<Raca> Raca){
        map<string, function<shared_ptr<Jogador>()>> jogadores = {{"bruxo", [&]()
                                                                   { return make_shared<Bruxo>(nome, nivel, Raca); }},
                                                                  {"ladrao", [&]()
                                                                   { return make_shared<Ladrao>(nome, nivel, Raca); }},
                                                                  {"artifice", [&]()
                                                                   { return make_shared<Artifice>(nome, nivel, Raca); }},
                                                                  {"guerreiro", [&]()
                                                                   { return make_shared<Guerreiro>(nome, nivel, Raca); }}};
        if (jogadores.count(classe))
            return jogadores[classe]();
        return nullptr;
    }
};

// Factory para inimigos: recebe o nome e retorna o inimigo correto via mapa de lambdas
class CriacaoInimigos{
public:
    static shared_ptr<Inimigo> criarInimigos(string nome){
        map<string, function<shared_ptr<Inimigo>()>> inimigos = {{"dragao", []()
                                                                  { return make_shared<Dragao>(); }},
                                                                 {"basilisco", []()
                                                                  { return make_shared<Basilisco>(); }},
                                                                 {"saqueadores", []()
                                                                  { return make_shared<Saqueadores>(); }}};
        if (inimigos.count(nome))
            return inimigos[nome]();
        return nullptr;
    }
};

// -------------- CLASSE MASMORRA ----------------
// Gerencia o combate em grupo: lista inimigos disponiveis, recebe a escolha do jogador
// e conduz os turnos alternados (jogadores agem, depois o inimigo ataca um alvo aleatorio)
class Masmorra{
public:
    map<string, shared_ptr<Inimigo>> inimigosDisponiveis;

    Masmorra(){
        this->inimigosDisponiveis = {{"1", CriacaoInimigos::criarInimigos("saqueadores")},
                                     {"2", CriacaoInimigos::criarInimigos("basilisco")},
                                     {"3", CriacaoInimigos::criarInimigos("dragao")}};
    }

    void entrar(){
        GerenciadorDeJogo &gerenciadorJogo = GerenciadorDeJogo::instancia();
        vector<shared_ptr<Jogador>> jogadoresVivos;
        for (auto j : gerenciadorJogo.jogadores){
            if (j->morto == false){
                jogadoresVivos.push_back(j);
            }
        }

        if (jogadoresVivos.empty()){
            cout << "Ta fazendo o que aqui? Ta todo mundo morto paizao!" << endl;
            return;
        }

        cout << "Bem vindo a masmorra" << endl;
        cout << "Escolha um inimigo para enfrentar: " << endl;
        for (auto par : this->inimigosDisponiveis){
            cout << par.first << ". " << par.second->getNome() << " // HP: " << par.second->getHP() << " // Dano: " << par.second->dano << endl;
        }
        string escolha;
        cout << "Escolha: ";
        cin >> escolha;

        if (this->inimigosDisponiveis.count(escolha) == 0){
            cout << "Burroooo! Opcao invalida!" << endl;
            return;
        }

        shared_ptr<Inimigo> inimigo = this->inimigosDisponiveis[escolha];
        this->combate(inimigo);
    }

    void combate(shared_ptr<Inimigo> inimigo){
        GerenciadorDeJogo &gerenciadorJogo = GerenciadorDeJogo::instancia();
        vector<shared_ptr<Jogador>> jogadores;
        vector<shared_ptr<Jogador>> fugitivos;
        for (auto j : gerenciadorJogo.jogadores){
            if (j->morto == false){
                jogadores.push_back(j);
            }
        }

        cout << "Turminha do barulho vs " << inimigo->getNome() << endl;

        while (inimigo->morto == false){
            vector<shared_ptr<Jogador>> jogadoresVivos;
            for (auto j : jogadores){
                if (j->morto == false){
                    if (find(fugitivos.begin(), fugitivos.end(), j) == fugitivos.end()){
                        jogadoresVivos.push_back(j);
                    }
                }
            }
            if (jogadoresVivos.empty()){
                cout << "\nO grupo todo morreu! GAME OVER!\n" << endl;
                return;
            }

            for (auto jogador : jogadoresVivos){
                cout << "Turno do " << jogador->getNome() << " // HP: " << jogador->getHP() << endl;
                cout << "1. Atacar" << endl;
                cout << "2. Curar" << endl;
                cout << "3. Recuperar Mana" << endl;
                cout << "4. Tacar pocao de dano" << endl;
                cout << "5. Ressucitar alguem" << endl;
                cout << "6. Fugir" << endl;
                cout << "7. Usar Habilidade (" << jogador->habilidade->getNome() << ")" << endl;

                string acao;
                cout << "Acao: ";
                cin >> acao;

                if (acao == "1"){
                    try{
                        jogador->atacar(inimigo);
                    }
                    catch (ExcecaoJogo &){
                        cout << "Acabou a mana ;-; !" << endl;
                    }
                }
                else if (acao == "2"){
                    try{
                        shared_ptr<Consumiveis> pocao = dynamic_pointer_cast<Consumiveis>(jogador->inventario.buscarItens("Pocao de Vida"));
                        pocao->usarItem(jogador, jogador);
                    }
                    catch (ExcecaoJogo &){
                        cout << "Acabou as pocoes ;-; !" << endl;
                    }
                }
                else if (acao == "3"){
                    try{
                        shared_ptr<Consumiveis> pocao = dynamic_pointer_cast<Consumiveis>(jogador->inventario.buscarItens("Pocao de Mana"));
                        pocao->usarItem(jogador);
                    }
                    catch (ExcecaoJogo &){
                        cout << "Acabou as pocoes ;-; !" << endl;
                    }
                }
                else if (acao == "4"){
                    cout << "Qual pocao deseja tacar: " << endl;
                    cout << "1. Dano de Fogo" << endl;
                    cout << "2. Dano de Gelo" << endl;
                    cout << "3. Dano por Relampago" << endl;
                    cout << "4. Dano Radiante" << endl;
                    cout << "5. Dano Venenoso" << endl;

                    string efeito;
                    cout << "Efeito: ";
                    cin >> efeito;

                    if (efeito == "1"){
                        try{
                            shared_ptr<Consumiveis> pocao = dynamic_pointer_cast<Consumiveis>(jogador->inventario.buscarItens("Pocao de Fogo"));
                            pocao->usarItem(jogador, inimigo);
                        }
                        catch (ExcecaoJogo &){
                            cout << "Acabou as pocoes ;-; !" << endl;
                        }
                    }
                    else if (efeito == "2"){
                        try{
                            shared_ptr<Consumiveis> pocao = dynamic_pointer_cast<Consumiveis>(jogador->inventario.buscarItens("Pocao de Gelo"));
                            pocao->usarItem(jogador, inimigo);
                        }
                        catch (ExcecaoJogo &){
                            cout << "Acabou as pocoes ;-; !" << endl;
                        }
                    }
                    else if (efeito == "3"){
                        try{
                            shared_ptr<Consumiveis> pocao = dynamic_pointer_cast<Consumiveis>(jogador->inventario.buscarItens("Pocao de Relampago"));
                            pocao->usarItem(jogador, inimigo);
                        }
                        catch (ExcecaoJogo &){
                            cout << "Acabou as pocoes ;-; !" << endl;
                        }
                    }
                    else if (efeito == "4"){
                        try{
                            shared_ptr<Consumiveis> pocao = dynamic_pointer_cast<Consumiveis>(jogador->inventario.buscarItens("Pocao Radiante"));
                            pocao->usarItem(jogador, inimigo);
                        }
                        catch (ExcecaoJogo &){
                            cout << "Acabou as pocoes ;-; !" << endl;
                        }
                    }
                    else if (efeito == "5"){
                        try{
                            shared_ptr<Consumiveis> pocao = dynamic_pointer_cast<Consumiveis>(jogador->inventario.buscarItens("Pocao Venenosa"));
                            pocao->usarItem(jogador, inimigo);
                        }
                        catch (ExcecaoJogo &){
                            cout << "Acabou as pocoes ;-; !" << endl;
                        }
                    }
                    else{
                        throw AcaoInvalidaException("Burroooo! Opcao invalida");
                    }
                }
                else if (acao == "5"){
                    try{
                        shared_ptr<Consumiveis> pocao = dynamic_pointer_cast<Consumiveis>(jogador->inventario.buscarItens("Orbe da Ressureicao"));
                        pocao->usarItem(jogador, jogador);
                    }
                    catch (ExcecaoJogo &){
                        cout << "Acabou o orbe ;-; !" << endl;
                    }
                }
                else if (acao == "6"){
                    int roll = randint(1, 20);
                    if (jogador->classe == "Ladrao"){
                        roll += jogador->furtividade;
                    }
                    if (roll > 15){
                        cout << jogador->getNome() << " fugiu com sucesso!" << endl;
                        fugitivos.push_back(jogador);
                        jogadoresVivos.erase(remove(jogadoresVivos.begin(), jogadoresVivos.end(), jogador), jogadoresVivos.end());
                        if (jogadoresVivos.size() == 0){
                            cout << "O grupo todo conseguiu fugir!" << endl;
                            return;
                        }
                    }
                    else{
                        cout << "HOJE NAO!" << endl;
                    }
                }
                else if (acao == "7"){
                    bool conseguiu = jogador->habilidade->usar(jogador, inimigo);
                    if (!conseguiu){
                        cout << "Acabou a mana ;-; !" << endl;
                    }
                }

                if (inimigo->morto){
                    break;
                }
            }

            if (inimigo->morto == false){
                jogadoresVivos = {};
                for (auto j : jogadores){
                    if (j->morto == false){
                        jogadoresVivos.push_back(j);
                    }
                }
                if (!jogadoresVivos.empty()){
                    shared_ptr<Jogador> alvo = choice(jogadoresVivos);
                    inimigo->atacar(alvo);
                }
            }
        }

        if (inimigo->morto){
            gerenciadorJogo.estado[inimigo->estadoMonstro] = true;
            cout << "O grupo de Herois venceu" << endl;
            for (auto jogador : jogadores){
                if (!jogador->morto){
                    jogador->ganharXP(inimigo->xpRecompensa);
                }
            }
            gerenciadorJogo.exibir();
        }
    }
};

// ---------- CLASSE MERCADAO -----------
// Permite ao grupo vender e comprar itens; interage com o Singleton GerenciadorDeJogo
class Mercadao{
public:
    void venderEspolio(shared_ptr<Item> item){
        GerenciadorDeJogo &gerenciadorJogo = GerenciadorDeJogo::instancia();
        gerenciadorJogo.adicionarOuro(item->valor);
        gerenciadorJogo.estado["itensVendidos"] += 1;
        cout << "[Mercadao]: " << item->str() << " foi barganhado!" << endl;
        gerenciadorJogo.exibir();
    }

    void comprarEspolio(shared_ptr<Item> item){
        GerenciadorDeJogo &gerenciadorJogo = GerenciadorDeJogo::instancia();
        gerenciadorJogo.comprarItem(item);
        gerenciadorJogo.estado["itensComprados"] += 1;
        cout << "[Mercadao]: " << item->str() << " foi barganhado!" << endl;
        gerenciadorJogo.exibir();
    }
};

// ---------- CLASSES MISSAO E QUADRO DE MISSOES ------------
// Missao armazena nome, descricao, recompensas e uma funcao lambda que verifica se a condicao foi atendida
class Missao{
public:
    string nome;
    string descricao;
    int recompensaXP;
    int recompensaOuro;
    function<bool(map<string, int>)> condicao;
    bool concluida;
    bool recompensaRetirada;

    Missao(string nome, string descricao, int recompensaXP, int recompensaOuro, function<bool(map<string, int>)> condicao){
        this->nome = nome;
        this->descricao = descricao;
        this->recompensaXP = recompensaXP;
        this->recompensaOuro = recompensaOuro;
        this->condicao = condicao;
        this->concluida = false;
        this->recompensaRetirada = false;
    }
};

// Agrupa todas as missoes disponiveis e verifica/distribui recompensas
class QuadroMissoes{
public:
    vector<Missao> missoes;

    QuadroMissoes(){
        this->missoes = {Missao("Cacador de Dragoes", "Derrote um dragao", 200, 150, [](map<string, int> estado)
                                { return estado["dragaoMorto"]; }),
                         Missao("Exterminador de Feras", "Derrote um basilisco", 150, 100, [](map<string, int> estado)
                                { return estado["basiliscoMorto"]; }),
                         Missao("Muambeiro", "Venda 5 item na loja", 30, 20, [](map<string, int> estado)
                                { return estado["itensVendidos"] >= 5; }),
                         Missao("Meu Dinheirinho", "Compre 5 item da loja", 50, 30, [](map<string, int> estado)
                                { return estado["itensComprados"] >= 5; })};
    }

    void verificarMissoes(){
        GerenciadorDeJogo &gerenciadorJogo = GerenciadorDeJogo::instancia();
        for (auto &missao : this->missoes){
            if (missao.concluida == false){
                if (missao.condicao(gerenciadorJogo.estado)){
                    missao.concluida = true;
                    cout << "Missao '" << missao.nome << "' concluida! Retire sua recompensa :>" << endl;
                }
            }
        }
    }

    bool retirarRecompensa(string nomeMissao, shared_ptr<Jogador> jogador){
        for (auto &missao : this->missoes){
            if (missao.nome == nomeMissao){
                if (missao.concluida == false){
                    cout << "Missao '" << nomeMissao << "' ainda nao concluida! " << endl;
                    return false;
                }
                if (missao.recompensaRetirada){
                    cout << "Recompensa ja foi retirada, circulando!" << endl;
                    return false;
                }
                jogador->ganharXP(missao.recompensaXP);
                GerenciadorDeJogo::instancia().adicionarOuro(missao.recompensaOuro);
                missao.recompensaRetirada = true;
                cout << "Recompensa retirada! Voce ganhou " << missao.recompensaXP << " de XP e " << missao.recompensaOuro << " de moedas de ouro" << endl;
                return true;
            }
        }
        return false;
    }
};

// ------------- CLASSE SISTEMAS DE ARQUIVOS (SAVE/LOAD) -------------------
// salvarJogo() serializa o estado do jogador em um arquivo JSON simples
// carregarJogo() le o JSON, reconstroi o mapa de dados e usa o Factory para recriar o objeto do jogador
class SistemasArquivos{
public:
    static void salvarJogo(shared_ptr<Jogador> jogador, string arquivo = "save.json"){
        map<string, string> dados = jogador->serializaDicionario();
        ofstream f(arquivo);
        f << "{\n";
        int contador = 0;
        for (auto par : dados){
            f << "  \"" << par.first << "\": \"" << par.second << "\"";
            contador++;
            if (contador < (int)dados.size())
                f << ",";
            f << "\n";
        }
        f << "}\n";
        f.close();
        cout << "Jogo salvo em " << arquivo << endl;
    }

    static shared_ptr<Jogador> carregarJogo(string arquivo = "save.json"){
        ifstream teste(arquivo);
        if (!teste.good()){
            cout << "Arquivo " << arquivo << " nao encontrado!" << endl;
            return nullptr;
        }
        teste.close();

        ifstream f(arquivo);
        string conteudo((istreambuf_iterator<char>(f)), istreambuf_iterator<char>());
        f.close();

        map<string, string> dados;
        regex padrao("\\\"([^\\\"]+)\\\"\\s*:\\s*\\\"([^\\\"]*)\\\"");
        auto inicio = sregex_iterator(conteudo.begin(), conteudo.end(), padrao);
        auto fim = sregex_iterator();
        for (auto it = inicio; it != fim; ++it){
            smatch match = *it;
            dados[match[1]] = match[2];
        }

        string classe = dados["classe"];
        shared_ptr<Jogador> jogador = Jogador::desserializaDicionario(dados);
        if (jogador != nullptr && dados.count("hpMax")){
            jogador->setHPMax(stoi(dados["hpMax"]));
        }
        cout << "Jogo carregado de " << arquivo << endl;
        return jogador;
    }
};

#endif
