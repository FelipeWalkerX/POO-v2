# RPG POO

Projeto de Programação Orientada a Objetos. Simula um RPG em modo texto com sistema de combate em grupo, inventário, itens consumíveis, missões e save/load.

---

## Requisitos

- Compilador C++17 (g++ 11+ ou clang++ 13+)
- Make
- Sistema: Linux, macOS ou Windows com MinGW

---

## Compilação e execução

```bash
# Compilar o jogo principal
make

# Rodar
./projeto
```

## Estrutura de arquivos

```
.
├── main.cpp          # Ponto de entrada; demonstra todas as funcionalidades
├── Excecoes.h        # Hierarquia de exceções customizadas do jogo
├── Utils.h           # Funções utilitárias: randint(), choice<T>()
├── Itens.h / .cpp    # Classes de itens, inventário, Adapter
├── Entidades.h / .cpp # Jogadores, Inimigos, Habilidades, Strategy de ataque
├── Sistemas.h / .cpp  # Singletons, Factories, Masmorra, Mercadão, Save/Load
└── Makefile            # Rodar o codigo com mais facilidade
```

---

## Funcionalidades

### Criação de personagens e inimigos (Factory)

`CriacaoJogadores` e `CriacaoInimigos` centralizam a construção de objetos polimórficos. O código que usa um `Jogador` nunca precisa saber qual subclasse está instanciando.

```cpp
shared_ptr<Jogador> j = CriacaoJogadores::criarJogadores("bruxo", "Lucien", 5, make_shared<MeioElfo>());
shared_ptr<Inimigo> d = CriacaoInimigos::criarInimigos("dragao");
```

Classes de jogadores disponíveis: `Bruxo`, `Ladrao`, `Artifice`, `Guerreiro`.  
Inimigos disponíveis: `Dragao`, `Basilisco`, `Saqueadores`.

### Raças

Cada raça aplica bônus de atributo no construtor da subclasse de `Jogador`.

| Raça      | Carisma | Inteligência | Agilidade |
|-----------|---------|--------------|-----------|
| MeioElfo  | +4      | +2           | +2        |
| Humano    | +2      | +2           | +2        |
| Tiefling  | +4      | +2           | +0        |

### Inventário e itens

O `Inventario` usa slots empilháveis (cada 9 unidades ocupa 1 slot, capacidade padrão de 20 slots).

Itens disponíveis via `CriacaoItens`:

- **Armas:** espada, machado, adaga, rapiera, foco arcano, foice
- **Armaduras:** malha, couro, ferro
- **Poções:** vida, mana, fogo, gelo, relâmpago, radiante, venenoso
- **Outros:** `OrbeRessureicao`, `ItemGenerico`, `AdaptadorArma`

### Padrão Strategy — ataque

`Jogador` delega como atacar a um objeto `EstrategiaAtaque`. Ao equipar uma arma, a estratégia troca para `AtaqueComArma`; ao desequipar, volta para `AtaqueDesarmado`. Nenhuma subclasse de `Jogador` precisa de `if (armaEquipada)` dentro do seu `atacar()`.

### Padrão Adapter — arma antiga

`ArmaAntiga` representa uma API legada com interface incompatível (`vestir()`/`tirar()` em vez de `equipar()`/`desequipar()`). `AdaptadorArma` traduz essa interface para o sistema atual sem alterar nenhuma das duas partes.

```cpp
shared_ptr<ArmaAntiga> antiga = make_shared<ArmaAntiga>("Machado Enferrujado", 18);
shared_ptr<Item> adapter = make_shared<AdaptadorArma>(antiga, 150, 2);
adapter->equipar(jogador); // funciona igual a qualquer Arma normal
```

### Habilidades de classe

Cada subclasse de `Jogador` recebe uma `Habilidade` exclusiva no construtor. O método `usar()` consome mana e aplica o efeito no inimigo.

| Classe    | Habilidade          | Custo de Mana |
|-----------|---------------------|---------------|
| Bruxo     | Bola de Fogo        | 40            |
| Ladrão    | Golpe Furtivo       | 20            |
| Artífice  | Granada Improvisada | 30            |
| Guerreiro | Golpe Brutal        | 10            |

### Singletons

`Logger` e `GerenciadorDeJogo` são Singletons — existem exatamente uma instância de cada durante toda a execução. O `GerenciadorDeJogo` centraliza o ouro do grupo, XP acumulado, lista de jogadores e inimigos e o mapa de estado para o `QuadroMissoes`.

```cpp
GerenciadorDeJogo &g = GerenciadorDeJogo::instancia();
Logger::instancia().log("mensagem");
```

### Masmorra

`Masmorra::entrar()` conduz o combate em grupo em modo texto. Em cada turno o jogador pode:

1. Atacar
2. Usar poção de vida
3. Usar poção de mana
4. Usar poção de dano elemental
5. Ressuscitar aliado
6. Fugir (rolagem de d20, bônus de furtividade para o Ladrão)
7. Usar habilidade de classe

Após a rodada dos jogadores, o inimigo ataca um alvo vivo aleatório. O combate termina quando o inimigo morre ou todos os jogadores morrem/fogem.

### Mercadão

```cpp
Mercadao().venderEspolio(item);  // adiciona ouro ao grupo
Mercadao().comprarEspolio(item); // debita ouro (lança SemDinheiroException se insuficiente)
```

### Quadro de Missões

Missões são verificadas por lambdas que leem o mapa de estado do `GerenciadorDeJogo`.

| Missão                | Condição              | Recompensa        |
|-----------------------|-----------------------|-------------------|
| Caçador de Dragões    | Derrotar o Dragão     | 200 XP + 150 ouro |
| Exterminador de Feras | Derrotar o Basilisco  | 150 XP + 100 ouro |
| Muambeiro             | Vender 5+ itens       | 30 XP + 20 ouro   |
| Meu Dinheirinho       | Comprar 5+ itens      | 50 XP + 30 ouro   |

### Save / Load

O estado do jogador é serializado em JSON simples (`save.json`). O carregamento usa regex para reconstruir o mapa de chave-valor e o Factory para recriar o objeto.

```cpp
SistemasArquivos::salvarJogo(jogador);
shared_ptr<Jogador> j = SistemasArquivos::carregarJogo();
```

---

## Padrões de projeto implementados

| Padrão    | Onde                                                   |
|-----------|--------------------------------------------------------|
| Factory   | `CriacaoJogadores`, `CriacaoItens`, `CriacaoInimigos` |
| Singleton | `Logger`, `GerenciadorDeJogo`                          |
| Strategy  | `EstrategiaAtaque` → `AtaqueComArma` / `AtaqueDesarmado` |
| Adapter   | `AdaptadorArma` adaptando `ArmaAntiga`                 |

---

## Exceções customizadas

Todas herdam de `ExcecaoJogo`, que por sua vez herda de `std::exception`.

| Classe                       | Quando é lançada                               |
|------------------------------|------------------------------------------------|
| `InventarioLotadoException`  | Inventário sem espaço para novo item           |
| `ItemNaoEncontradoException` | Item buscado ou removido não existe            |
| `RecursoEsgotadoException`   | Poção ou orbe com `quantidade == 0`            |
| `SemDinheiroException`       | Ouro insuficiente para compra                  |
| `LimiteJogadoresException`   | Grupo já com 5 jogadores                       |
| `AcaoInvalidaException`      | Ação de menu inválida, sem mana, item inviável |

---


