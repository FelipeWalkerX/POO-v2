#include "Excecoes.h"
#include "Itens.h"
#include "Entidades.h"
#include "Sistemas.h"
#include "Utils.h"
#include <ctime>
using namespace std;

// --------------- MAIN ----------------
// Ponto de entrada do programa; demonstra todas as funcionalidades implementadas:
// criacao de jogadores e inimigos via Factory, uso de itens, combate, Singleton,
// quadro de missoes e sistema de save/load

int main(){
    srand(time(nullptr));

    // Criando jogadores pelo Factory
    shared_ptr<Jogador> jogador1 = CriacaoJogadores::criarJogadores("bruxo", "Lucien", 5, make_shared<MeioElfo>());
    shared_ptr<Jogador> jogador2 = CriacaoJogadores::criarJogadores("ladrao", "Sevras", 5, make_shared<MeioElfo>());
    shared_ptr<Jogador> jogador3 = CriacaoJogadores::criarJogadores("artifice", "Jimothy", 5, make_shared<Tiefling>());
    shared_ptr<Jogador> jogador4 = CriacaoJogadores::criarJogadores("guerreiro", "Tsarin", 5, make_shared<Humano>());

    // Adicionando jogadores no Singleton (GerenciadorDeJogo) para o grupo poder entrar na masmorra junto
    GerenciadorDeJogo &gerenciadorJogo = GerenciadorDeJogo::instancia();
    gerenciadorJogo.adicionarJogador(jogador1);
    gerenciadorJogo.adicionarJogador(jogador2);
    gerenciadorJogo.adicionarJogador(jogador3);
    gerenciadorJogo.adicionarJogador(jogador4);

    // Criando itens pelo Factory
    shared_ptr<Consumiveis> pocaoVida = CriacaoItens::criarPocao("vida", 3);
    shared_ptr<Consumiveis> pocaoMana = CriacaoItens::criarPocao("mana", 2);
    shared_ptr<Consumiveis> fogoItem = CriacaoItens::criarPocao("fogo", 2);
    shared_ptr<Consumiveis> geloItem = CriacaoItens::criarPocao("gelo", 1);
    shared_ptr<Consumiveis> orbeItem = make_shared<OrbeRessureicao>(1);
    shared_ptr<Arma> espada = CriacaoItens::criarArma("espada");
    shared_ptr<Arma> foice = CriacaoItens::criarArma("foice");
    shared_ptr<Armadura> armaduraFerro = CriacaoItens::criarArmaduras("ferro");

    // Adicionando itens no inventario de cada jogador
    jogador1->inventario.adicionarItem(pocaoVida); // Bruxo com pocoes de vida, mana e fogo
    jogador1->inventario.adicionarItem(pocaoMana);
    jogador1->inventario.adicionarItem(fogoItem);
    jogador2->inventario.adicionarItem(espada);        // Ladrao com espada
    jogador3->inventario.adicionarItem(orbeItem);      // Artifice com orbe de ressureicao
    jogador4->inventario.adicionarItem(armaduraFerro); // Guerreiro com armadura de ferro

    cout << "\n--- INVENTARIO DO JOGADOR 1 ---" << endl;
    jogador1->inventario.listarItens();

    // Equipando arma e armadura
    cout << "\n--- EQUIPANDO ---" << endl;
    espada->equipar(jogador2);        // Ladrao equipa a espada
    armaduraFerro->equipar(jogador4); // Guerreiro equipa a armadura

    // Demonstracao do padrao Adapter: uma "arma antiga" (interface incompativel,
    // com vestir()/tirar() em vez de equipar()/desequipar()) sendo usada no jogo atual
    // atraves do AdaptadorArma, sem precisar mudar nem a ArmaAntiga nem o resto do sistema
    cout << "\n--- ADAPTER: EQUIPANDO ARMA DE SISTEMA ANTIGO ---" << endl;
    shared_ptr<ArmaAntiga> machadoAntigo = make_shared<ArmaAntiga>("Machado Enferrujado", 18);
    shared_ptr<Item> adaptador = make_shared<AdaptadorArma>(machadoAntigo, 150, 2);
    adaptador->equipar(jogador3);    // Artifice equipa a arma antiga atraves do Adapter, igual equiparia uma Arma normal
    adaptador->desequipar(jogador3); // Desequipa de volta, so para nao alterar o resto da demonstracao abaixo (que espera o Artifice desarmado)

    // Testando heranca com isinstance (compara jogador com Bruxo, pra saber se )
    cout << "\n--- VERIFICANDO HERANCA ---" << endl;
    cout << "jogador1 e Bruxo? " << (dynamic_pointer_cast<Bruxo>(jogador1) != nullptr) << endl;   // Compara jogador com a classe Bruxo, pra saber se ele e realmente da classe Bruxo (e como ele é, vai retornar True)
    cout << "jogador1 e Jogador? " << (jogador1 != nullptr) << endl;                              // Compara jogador com a classe Jogador e como Bruxo herda de Jogador (ai o polimorfismo), retorna True tambem
    cout << "jogador1 e Ladrao? " << (dynamic_pointer_cast<Ladrao>(jogador1) != nullptr) << endl; // Compara jogador com  a classe Ladrao, como ele nao é, retorna "False"

    // Status de todos os jogadores
    cout << "\n--- STATUS INICIAL ---" << endl;
    cout << jogador1 << endl;
    cout << jogador2 << endl;
    cout << jogador3 << endl;
    cout << jogador4 << endl;

    // Combate entre jogadores (testando polimorfismo do atacar)
    cout << "\n--- COMBATE ENTRE JOGADORES ---" << endl;
    jogador1->atacar(jogador2); // Bruxo ataca Ladrao com magia
    jogador2->atacar(jogador1); // Ladrao ataca Bruxo com espada equipada
    jogador3->atacar(jogador1); // Artifice ataca Bruxo (sem arma, tenta usar pedra ou tapa)
    jogador4->atacar(jogador1); // Guerreiro ataca Bruxo com forca

    // Usando itens (testando polimorfismo do usarItem)
    cout << "\n--- USANDO ITENS ---" << endl;
    try{
        pocaoVida->usarItem(jogador1, jogador1); // Bruxo se cura
        pocaoMana->usarItem(jogador1);           // Bruxo recupera mana
        fogoItem->usarItem(jogador1, jogador2);  // Bruxo usa pocao de fogo no Ladrao (usuario - > Bruxo, alvo - > Ladrao)
        orbeItem->usarItem(jogador3, jogador1);  // Artifice tenta ressucitar o Bruxo com o orbe
    }
    catch (ExcecaoJogo &e){
        cout << e.what() << endl; // Se nao tiver pocao ou orbe, da erro
    }

    // Artifice criando item e atacando com pedra
    cout << "\n--- ARTIFICE CRIANDO ITEM ---" << endl;
    dynamic_pointer_cast<Artifice>(jogador3)->criarItem("vida", 2); // Artifice tenta criar 2 pocoes de vida
    jogador3->inventario.listarItens();                             // Listando o inventario do artifice depois de criar o item
    jogador3->atacar(jogador2);                                     // Artifice ataca o ladrao (se tiver pedra, usa ela, se nao vai no tapa)

    // Removendo item do inventario
    cout << "\n--- REMOVENDO ITEM ---" << endl;
    try{
        jogador1->inventario.removerItem("Pocao de Fogo");    // Remove a pocao de fogo do inventario do Bruxo
        jogador1->inventario.removerItem("Item Inexistente"); // Tenta remover um item que nao existe
    }
    catch (ExcecaoJogo &e){
        cout << e.what() << endl; // Da erro porque o item nao existe
    }

    // Desequipando itens
    cout << "\n--- DESEQUIPANDO ---" << endl;
    espada->desequipar(jogador2);        // Ladrao larga a espada de volta pro inventario
    armaduraFerro->desequipar(jogador4); // Guerreiro tira a armadura de volta pro inventario

    // ---------Testando o Singleton (GerenciadorDeJogo, Mercadao e QuadroMissoes)----------
    cout << "\n--- SINGLETON ---" << endl;
    try{
        Mercadao().venderEspolio(espada); // Vendendo a espada no mercadao (adiciona ouro no cofrinho do grupo)
        Mercadao().comprarEspolio(foice); // Comprando a foice (desconta ouro do cofrinho do grupo)
        gerenciadorJogo.exibir();         // Exibindo o estado do gerenciador de jogo
    }
    catch (ExcecaoJogo &e){
        cout << e.what() << endl; // Se nao tiver grana suficiente, cai aqui
    }

    // Testando o QuadroMissoes
    cout << "\n--- QUADRO DE MISSOES ---" << endl;
    QuadroMissoes quadro;
    quadro.verificarMissoes(); // Verifica se alguma missao foi concluida

    // Testando inimigos pela Factory
    cout << "\n--- INIMIGOS ---" << endl;
    shared_ptr<Inimigo> dragao = CriacaoInimigos::criarInimigos("dragao");
    shared_ptr<Inimigo> basilisco = CriacaoInimigos::criarInimigos("basilisco");
    shared_ptr<Inimigo> saqueadores = CriacaoInimigos::criarInimigos("saqueadores");

    gerenciadorJogo.adicionarInimigos(dragao); // Adicionando inimigos no gerenciador
    gerenciadorJogo.adicionarInimigos(basilisco);
    gerenciadorJogo.adicionarInimigos(saqueadores);

    // Testando a Masmorra (combate em grupo)
    cout << "\n--- MASMORRA ---" << endl;
    Masmorra().entrar(); // O grupo todo entra na masmorra e escolhe um inimigo pra enfrentar

    // Verificando missoes de novo depois do combate com inimigos
    cout << "\n--- VERIFICANDO MISSOES APOS COMBATE ---" << endl;
    quadro.verificarMissoes(); // Agora pode ter alguma missao concluida (se matou o dragao ou basilisco)
    try{
        quadro.retirarRecompensa("Cacador de Dragoes", jogador4);    // Guerreiro tenta retirar a recompensa de matar o dragao
        quadro.retirarRecompensa("Exterminador de Feras", jogador1); // Bruxo tenta retirar a recompensa de matar o basilisco
    }
    catch (ExcecaoJogo &e){
        cout << e.what() << endl; // Se nao tiver recompensa pra tirar, da erro
    }

    // XP ganhado pelo grupo
    cout << "\n--- XP ---" << endl;
    jogador1->ganharXP(50); // Dando xp extra pro Bruxo

    // Save/Load do jogo
    cout << "\n--- SAVE/LOAD ---" << endl;
    SistemasArquivos::salvarJogo(jogador1);                                  // Salva o estado do Bruxo em um json
    shared_ptr<Jogador> jogadorCarregado = SistemasArquivos::carregarJogo(); // Carrega o save de volta
    cout << jogadorCarregado << endl;                                        // Printa o jogador carregado pra ver se bateu com o salvo

    // Status final de todos os jogadores
    cout << "\n--- STATUS FINAL ---" << endl;
    cout << jogador1 << endl;
    cout << jogador2 << endl;
    cout << jogador3 << endl;
    cout << jogador4 << endl;

    // Exibindo todos os logs da partida
    cout << "\n--- LOGS DA PARTIDA ---" << endl;
    Logger::instancia().exibirLogs();

    return 0;
}
