#include "Itens.h"
#include "Entidades.h"
#include <algorithm>

// --------------- IMPLEMENTACAO DE INVENTARIO ---------------

Inventario::Inventario(int capacidade){
    this->itens = {};
    this->capacidade = capacidade;
}

bool Inventario::adicionarItem(shared_ptr<Item> item){
    int totalEspaco = 0;
    for (auto i : this->itens){
        totalEspaco += (i->quantidade + 8) / 9;
    }
    if (totalEspaco + (item->quantidade + 8) / 9 > this->capacidade){
        throw InventarioLotadoException("Inventario Lotado! Capacidade maxima: " + to_string(totalEspaco) + "/" + to_string(this->capacidade));
    }
    else{
        this->itens.push_back(item);
        cout << "Item " << item->nomeItem << " adicionado com sucesso" << endl;
        return true;
    }
}

bool Inventario::removerItem(const string &nomeItem){
    for (auto it = this->itens.begin(); it != this->itens.end(); ++it){
        shared_ptr<Item> item = *it;
        if (item->nomeItem == nomeItem){
            this->itens.erase(it);
            cout << nomeItem << " removido do inventario" << endl;
            return true;
        }
    }
    throw ItemNaoEncontradoException("O item " + nomeItem + " nao foi localizado ou nao existe");
}

void Inventario::listarItens(){
    cout << "Inventario: " << endl;
    int totalEspaco = 0;
    int i = 1;
    for (auto item : this->itens){
        int pilhas = (item->quantidade + 8) / 9;
        totalEspaco += pilhas;
        cout << i << ". " << item->nomeItem << ", quantidade: " << item->quantidade << endl;
        i += 1;
    }
    cout << " \nEspaco total: " << totalEspaco << "/" << this->capacidade << endl;
}

shared_ptr<Item> Inventario::buscarItens(const string &nomeItem){
    for (auto item : this->itens){
        if (item->nomeItem == nomeItem){
            return item;
        }
    }
    throw ItemNaoEncontradoException("Item " + nomeItem + " nao encontrado!");
}

// --------------- IMPLEMENTACAO DE ARMA (equipar/desequipar usam Jogador completo) ---------------

void Arma::equipar(shared_ptr<Jogador> jogador){
    if (jogador->armaEquipada == nullptr){
        jogador->armaEquipada = shared_from_this_item();
        jogador->dano = this->dano;
        jogador->estrategiaAtaque = make_shared<AtaqueComArma>(); // Strategy: troca o "como atacar" pra versao com arma
        auto &itens = jogador->inventario.itens;
        itens.erase(remove_if(itens.begin(), itens.end(), [&](shared_ptr<Item> item)
                              { return item.get() == this; }),
                    itens.end());
        cout << jogador->getNome() << " equipou a " << this->nomeItem << endl;
    }
    else{
        cout << jogador->getNome() << ", ja esta com a " << this->nomeItem << " equipada!" << endl;
    }
}

void Arma::desequipar(shared_ptr<Jogador> jogador){
    if (jogador->armaEquipada != nullptr){
        shared_ptr<Item> item = jogador->armaEquipada;
        jogador->armaEquipada = nullptr;
        jogador->estrategiaAtaque = make_shared<AtaqueDesarmado>(); // Strategy: volta o "como atacar" pra versao desarmada
        jogador->inventario.adicionarItem(item);
        jogador->dano = 0;
        cout << jogador->getNome() << " largou a " << this->nomeItem << endl;
    }
    else{
        cout << jogador->getNome() << ", ja guardou a " << this->nomeItem << "!" << endl;
    }
}

// --------------- IMPLEMENTACAO DO ADAPTER (AdaptadorArma) ---------------

void AdaptadorArma::equipar(shared_ptr<Jogador> jogador){
    if (jogador->armaEquipada == nullptr){
        jogador->armaEquipada = shared_from_this_item();
        jogador->dano = this->armaAntiga->forcaArma; // Traduz forcaArma para o dano que o jogo usa
        jogador->estrategiaAtaque = make_shared<AtaqueComArma>(); // Mesmo Strategy de antes, sem nenhuma mudanca
        auto &itens = jogador->inventario.itens;
        itens.erase(remove_if(itens.begin(), itens.end(), [&](shared_ptr<Item> item)
                              { return item.get() == this; }),
                    itens.end());
        this->armaAntiga->vestir(jogador->getNome()); // Chama o metodo da interface antiga por baixo dos panos
    }
    else{
        cout << jogador->getNome() << ", ja esta com a " << this->nomeItem << " equipada!" << endl;
    }
}

void AdaptadorArma::desequipar(shared_ptr<Jogador> jogador){
    if (jogador->armaEquipada != nullptr){
        shared_ptr<Item> item = jogador->armaEquipada;
        jogador->armaEquipada = nullptr;
        jogador->estrategiaAtaque = make_shared<AtaqueDesarmado>();
        jogador->inventario.adicionarItem(item);
        jogador->dano = 0;
        this->armaAntiga->tirar(jogador->getNome()); // Chama o metodo da interface antiga por baixo dos panos
    }
    else{
        cout << jogador->getNome() << ", ja guardou a " << this->nomeItem << "!" << endl;
    }
}

// --------------- IMPLEMENTACAO DE ARMADURA ---------------

void Armadura::equipar(shared_ptr<Jogador> jogador){
    if (jogador->armaduraEquipada == nullptr){
        jogador->armaduraEquipada = shared_from_this_item();
        jogador->defesaTotal += this->defesa;
        auto &itens = jogador->inventario.itens;
        itens.erase(remove_if(itens.begin(), itens.end(), [&](shared_ptr<Item> item)
                              { return item.get() == this; }),
                    itens.end());
        cout << jogador->getNome() << " vestiu sua " << this->nomeItem << endl;
    }
    else{
        cout << jogador->getNome() << ", ja esta com a " << this->nomeItem << " equipada!" << endl;
    }
}

void Armadura::desequipar(shared_ptr<Jogador> jogador){
    if (jogador->armaduraEquipada != nullptr){
        shared_ptr<Item> item = jogador->armaduraEquipada;
        jogador->armaduraEquipada = nullptr;
        jogador->defesaTotal -= this->defesa;
        jogador->inventario.adicionarItem(item);
        cout << jogador->getNome() << " tirou a " << this->nomeItem << endl;
    }
    else{
        cout << jogador->getNome() << ", ja esta sem a " << this->nomeItem << "!" << endl;
    }
}

// Implementado aqui pois precisa de Armadura completa (dynamic_pointer_cast<Armadura>)
int Jogador::getArmadura(){
    int bonus = 0;
    if (this->armaduraEquipada != nullptr){
        shared_ptr<Armadura> armadura = dynamic_pointer_cast<Armadura>(this->armaduraEquipada);
        if (armadura != nullptr)
            bonus = armadura->defesa;
    }
    return this->armaduraBase + bonus;
}

// --------------- IMPLEMENTACAO DAS POCOES (usarItem) ---------------

bool PocaoVida::usarItem(shared_ptr<Jogador> usuario, shared_ptr<Jogador> alvo){
    if (this->quantidade > 0){
        if (alvo->morto || usuario->morto){
            if (usuario != alvo){
                if (alvo->morto){
                    cout << alvo->getNome() << " esta morto e nao pode receber cura" << endl;
                    return false;
                }
                else if (usuario->morto){
                    cout << usuario->getNome() << " esta morto e nao pode curar " << alvo->getNome() << endl;
                    return false;
                }
            }
            else{
                cout << usuario->getNome() << " esta morto e nao pode se curar" << endl;
                return false;
            }
        }

        alvo->curar(20);
        this->quantidade -= 1;
        if (usuario->getNome() == alvo->getNome()){
            cout << usuario->getNome() << " se curou! || HP: " << usuario->getHP() << "/" << usuario->getHPMax() << endl;
            return true;
        }

        cout << usuario->getNome() << " usou " << this->nomeItem << " em " << alvo->getNome() << " com sucesso! || HP: " << alvo->getHP() << "/" << alvo->getHPMax() << endl;
        return true;
    }
    else{
        throw RecursoEsgotadoException("Voce nao tem mais esta pocao!");
    }
}

bool PocaoMana::usarItem(shared_ptr<Jogador> usuario){
    if (this->quantidade > 0){
        if (usuario->morto){
            cout << usuario->getNome() << " esta morto e nao pode recuperar mana" << endl;
            return false;
        }
        usuario->mana += 20;
        if (usuario->mana > 100){
            usuario->mana = 100;
        }
        this->quantidade -= 1;
        cout << usuario->getNome() << " usou " << this->nomeItem << "! || Mana: " << usuario->mana << endl;
        return true;
    }
    else{
        throw RecursoEsgotadoException("Voce nao tem mais esta pocao!");
    }
}

bool PocaoDanoElemental::usarItem(shared_ptr<Jogador> usuario, shared_ptr<Jogador> alvo){
    if (this->quantidade > 0){
        if (usuario->morto){
            cout << usuario->getNome() << " esta morto e nao pode usar item" << endl;
            return false;
        }
        this->quantidade -= 1;
        alvo->receberDano(this->dano);
        cout << usuario->getNome() << " usou " << this->nomeItem << " em " << alvo->getNome() << "! || " << alvo->getNome() << ": " << alvo->getHP() << "/" << alvo->getHPMax() << " HP" << endl;
        return true;
    }
    else{
        throw RecursoEsgotadoException("Voce nao tem mais esta pocao!\n");
    }
}

bool PocaoDanoElemental::usarItem(shared_ptr<Jogador> usuario, shared_ptr<Inimigo> alvo){
    if (this->quantidade > 0){
        if (usuario->morto){
            cout << usuario->getNome() << " esta morto e nao pode usar item\n" << endl;
            return false;
        }
        this->quantidade -= 1;
        alvo->receberDano(this->dano, usuario);
        cout << usuario->getNome() << " usou " << this->nomeItem << " em " << alvo->getNome() << "! || " << alvo->getNome() << ": " << alvo->getHP() << "/" << alvo->getHPMax() << " HP" << endl;
        return true;
    }
    else{
        throw RecursoEsgotadoException("Voce nao tem mais esta pocao!");
    }
}

bool OrbeRessureicao::usarItem(shared_ptr<Jogador> usuario, shared_ptr<Jogador> alvo){
    if (alvo != usuario){
        if (usuario->morto){
            cout << usuario->getNome() << " tambem esta morto e nao pode ressucitar " << alvo->getNome() << endl;
            return false;
        }
        if (usuario->morto == false){
            cout << alvo->getNome() << " ainda esta vivo" << endl;
            return false;
        }
        if (this->quantidade > 0){
            alvo->morto = false;
            alvo->setHP(1);
            this->quantidade -= 1;
            cout << alvo->getNome() << " foi ressucitado por " << usuario->getNome() << " || " << alvo->getNome() << ": " << alvo->getHP() << "/" << alvo->getHPMax() << endl;
            return true;
        }
        else{
            throw RecursoEsgotadoException("Voce nao tem mais orbes!");
        }
    }
    else{
        cout << "Nao é permitido usar o orbe em si mesmo" << endl;
        return false;
    }
}
