#ifndef UTILS_H
#define UTILS_H

#include <vector>
#include <memory>
using namespace std;

/*---------------- FUNCOES UTILITARIAS -----------------
Compartilhadas entre Entidades (rolagem de dado nos ataques) e Sistemas (sorteio de alvo)
Gera um numero inteiro aleatorio no intervalo [inicio, fim] (inclusivo nos dois lados)
*/

//Comentarios com Doxygen
/**
 * @file Utils.h
 * @brief Funcoes utilitarias compartilhadas entre os modulos do jogo.
 *
 * Contem geracao de numeros aleatorios e selecao aleatoria de elementos,
 * usadas tanto nos ataques das entidades quanto no sorteio de alvos na Masmorra.
 */
 
/**
 * @brief Gera um numero inteiro aleatorio no intervalo fechado [inicio, fim].
 *
 * @param inicio Valor minimo (inclusivo).
 * @param fim    Valor maximo (inclusivo).
 * @return Inteiro aleatorio entre inicio e fim.
 */

inline int randint(int inicio, int fim){
    return inicio + rand() % (fim - inicio + 1);
}

/**
 * @brief Escolhe aleatoriamente um elemento de um vetor de shared_ptr.
 *
 * @tparam T Tipo do objeto gerenciado pelo shared_ptr.
 * @param lista Vetor de shared_ptr de onde o elemento sera sorteado.
 * @return shared_ptr para um elemento aleatorio da lista, ou nullptr se a lista estiver vazia.
 */

template <typename T>
shared_ptr<T> choice(const vector<shared_ptr<T>> &lista){
    if (lista.empty())
        return nullptr;
    int indice = randint(0, (int)lista.size() - 1);
    return lista[indice];
}
/*Comentarios legado
Escolhe aleatoriamente um elemento de um vetor de shared_ptr
Retorna nullptr se a lista estiver vazia
*/
#endif
