#include <gtest/gtest.h>
#include <memory>
#include <fstream>
#include "Entidades.h"
#include "Itens.h"
#include "Sistemas.h"



// =========================================================================
// TESTES DE ENTIDADES E ITENS 
// =========================================================================

TEST(EntidadesTest, AtributosIniciaisGuerreiro) {
    auto racaHumano = std::make_shared<Humano>();
    auto guerreiro = std::make_shared<Guerreiro>("Ragnar", 1, racaHumano);

    EXPECT_EQ(guerreiro->getNome(), "Ragnar");
    EXPECT_EQ(guerreiro->getHP(), 250);
    EXPECT_EQ(guerreiro->getHPMax(), 250);
    EXPECT_EQ(guerreiro->classe, "Guerreiro");
}

TEST(ItensTest, BonusDeRacaNoPersonagem) {
    auto racaMeioElfo = std::make_shared<MeioElfo>();
    auto bruxo = std::make_shared<Bruxo>("Kael", 1, racaMeioElfo);
    // Bruxo base (20) + MeioElfo (+4) = 24
    EXPECT_EQ(bruxo->carisma, 24);
}

TEST(ItensTest, FuncionamentoDoAdapterArmaAntiga) {
    auto machadoLegado = std::make_shared<ArmaAntiga>("Machado Ancestral", 40);
    auto adaptador = std::make_shared<AdaptadorArma>(machadoLegado, 500, 2);

    EXPECT_EQ(adaptador->nomeItem, "Machado Ancestral");
    EXPECT_EQ(adaptador->valor, 500);
}

// =========================================================================
// TESTES DOS SISTEMAS GLOBAIS (Sistemas.h)
// =========================================================================

// Teste 4: Padrão Singleton - GerenciadorDeJogo
TEST(SistemasTest, SingletonGerenciadorDeJogoUnicidade) {
    GerenciadorDeJogo &g1 = GerenciadorDeJogo::instancia();
    GerenciadorDeJogo &g2 = GerenciadorDeJogo::instancia();
    
    // Ambas as referências devem apontar exatamente para o mesmo endereço de memória
    EXPECT_EQ(&g1, &g2);
    
    int ouroInicial = g1.ouro;
    g1.adicionarOuro(100);
    EXPECT_EQ(g2.ouro, ouroInicial + 100);
}

// Teste 5: Padrão Factory - Criação Polimórfica de Itens e Jogadores
TEST(SistemasTest, FactoryCriacaoDeObjetos) {
    // Testando fábrica de itens
    auto arma = CriacaoItens::criarArma("espada");
    ASSERT_NE(arma, nullptr);
    EXPECT_EQ(arma->nomeItem, "Dualiso");
    EXPECT_EQ(arma->dano, 25);

    // Testando fábrica de jogadores
    auto raca = std::make_shared<Humano>();
    auto jogador = CriacaoJogadores::criarJogadores("guerreiro", "Thorin", 1, raca);
    ASSERT_NE(jogador, nullptr);
    EXPECT_EQ(jogador->getNome(), "Thorin");
    EXPECT_EQ(jogador->classe, "Guerreiro");
}

// Teste 6: Quadro de Missões e Predicados Baseados em Estado
TEST(SistemasTest, QuadroDeMissoesEVerificacao) {
    GerenciadorDeJogo &gerenciador = GerenciadorDeJogo::instancia();
    QuadroMissoes quadro;

    // Força o estado no Singleton para simular a derrota do Basilisco
    gerenciador.estado["basiliscoMorto"] = 1;
    quadro.verificarMissoes();

    // Encontra a missão específica na lista do quadro para avaliar o estado interno dela
    bool missaoConcluida = false;
    for (const auto &missao : quadro.missoes) {
        if (missao.nome == "Exterminador de Feras") {
            missaoConcluida = missao.concluida;
            break;
        }
    }
    EXPECT_TRUE(missaoConcluida);
}

// Teste 7: Sistema de Arquivos - Serialização e Desserialização (Save/Load)
TEST(SistemasTest, SalvarECarregarJogoJSON) {
    std::string arquivoTeste = "save_teste.json";
    auto raca = std::make_shared<Humano>();
    auto original = std::make_shared<Guerreiro>("Conan", 1, raca);
    original->setHPMax(300);

    // Exporta para arquivo usando a infraestrutura do seu sistema
    SistemasArquivos::salvarJogo(original, arquivoTeste);

    // Reconstrói a partir do arquivo gerado
    auto carregado = SistemasArquivos::carregarJogo(arquivoTeste);
    ASSERT_NE(carregado, nullptr);

    EXPECT_EQ(carregado->getNome(), original->getNome());
    EXPECT_EQ(carregado->classe, original->classe);
    EXPECT_EQ(carregado->getHPMax(), 300);

    // Remove o arquivo de teste gerado para não poluir o diretório
    std::remove(arquivoTeste.c_str());
}

// Ponto de entrada padrão do Google Test
int main(int argc, char **argv) {
    ::testing::InitGoogleTest(&argc, argv);
    return RUN_ALL_TESTS();
}