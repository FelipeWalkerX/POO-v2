#ifndef ITENS_H
#define ITENS_H

#include <iostream>
#include <string>
#include <vector>
#include <memory>
#include <sstream>
#include <algorithm>
#include "Excecoes.h"
using namespace std;

/*Comentarios legado
Forward declarations: as classes de item aqui so precisam de ponteiro para Jogador/Inimigo,
a definicao completa de ambos fica em Entidades.h e e incluida so dentro de Itens.cpp
*/


/**
 * @file Itens.h
 * @brief Classes de itens, inventario, racas e o padrao Adapter para arma legada.
 *
 * Define a hierarquia de Item (Arma, Armadura, Consumiveis, ItemGenerico),
 * a classe Inventario com empilhamento de consumiveis, as racas dos jogadores
 * e o padrao Adapter que adapta ArmaAntiga para a interface Item atual.
 */
 
// Forward declarations: as classes de item aqui so precisam de ponteiro para Jogador/Inimigo,
// a definicao completa de ambos fica em Entidades.h e e incluida so dentro de Itens.cpp
class Jogador;
class Inimigo;

// --------------- CLASSE RACA (BASE) -----------------
// Classe base para as racas dos jogadores; define bonus de atributos aplicados no construtor das subclasses

/**
 * @brief Classe base para as racas dos jogadores.
 *
 * Define os bonus de atributos (carisma, inteligencia, agilidade) que cada
 * raca concreta aplica no construtor da subclasse de Jogador correspondente.
 */
class Raca{
public:
    int bonusCarisma;       ///< Bonus de carisma aplicado ao jogador.
    int bonusInteligencia;  ///< Bonus de inteligencia aplicado ao jogador.
    int bonusAgilidade;     ///< Bonus de agilidade aplicado ao jogador.

    /**
     * @brief Constroi uma Raca com os bonus especificados.
     * @param bonusCarisma      Bonus de carisma (padrao 0).
     * @param bonusInteligencia Bonus de inteligencia (padrao 0).
     * @param bonusAgilidade    Bonus de agilidade (padrao 0).
     */

    Raca(int bonusCarisma = 0, int bonusInteligencia = 0, int bonusAgilidade = 0){
        this->bonusCarisma = bonusCarisma;  
        this->bonusInteligencia = bonusInteligencia;     
        this->bonusAgilidade = bonusAgilidade;  
    }

    /**
     * @brief Retorna o nome da raca como string.
     * @return Nome da raca.
     */
    virtual string nomeClasse() const{
        return "Raca";
    }

    // Mudar pra ele mostrar o nome da Raca e nao o endereco de memoria de onde ta
    virtual string str() const{
        return nomeClasse();
    }

    virtual ~Raca() = default;
};

// ------------ RACAS CONCRETAS -----------------
// Cada subclasse define os bonus especificos da raca via construtor da classe base Raca

/**
 * @brief Raca Meio-Elfo: +4 carisma, +2 inteligencia, +2 agilidade.
 */
class MeioElfo : public Raca{
public:
    MeioElfo() : Raca(4, 2, 2) {}
    string nomeClasse() const override { return "MeioElfo"; }
};

/**
 * @brief Raca Humano: +2 em todos os atributos.
 */
class Humano : public Raca{
public:
    Humano() : Raca(2, 2, 2) {}
    string nomeClasse() const override { return "Humano"; }
};

/**
 * @brief Raca Tiefling: +4 carisma, +2 inteligencia, sem bonus de agilidade.
 */
class Tiefling : public Raca{
public:
    Tiefling() : Raca(4, 2, 0) {}
    string nomeClasse() const override { return "Tiefling"; }
};

// ------------- CLASSE ITEM (BASE ABSTRATA) ----------------
// Define a interface comum para todos os itens do jogo (armas, armaduras, consumiveis)
// equipar/desequipar sao metodos abstratos implementados por cada subclasse

/**
 * @brief Classe base abstrata para todos os itens do jogo.
 *
 * Define a interface comum de equipar/desequipar e os atributos basicos
 * (nome, valor, espaco em slots e quantidade empilhada).
 * Arma, Armadura, Consumiveis e ItemGenerico herdam desta classe.
 */
class Item{
public:
    string nomeItem;    ///< Nome de exibicao do item.
    int valor;      ///< Valor em ouro do item (para compra/venda no Mercadao).
    int espaco;     ///< Numero de slots que o item ocupa no inventario.
    int quantidade;      ///< Quantidade empilhada (relevante para consumiveis).

    /**
     * @brief Constroi um Item com nome, valor e espaco em slots.
     * @param nomeItem Nome do item.
     * @param valor    Valor em ouro.
     * @param espaco   Slots ocupados no inventario.
     */

    Item(string nomeItem, int valor, int espaco){
        this->nomeItem = nomeItem;
        this->valor = valor;
        this->espaco = espaco;
        this->quantidade = 1;
    }

    /**
     * @brief Equipa o item no jogador, aplicando seus efeitos e removendo-o do inventario.
     * @param jogador Jogador que equipara o item.
     */
    virtual void equipar(shared_ptr<Jogador> jogador) = 0;
    
    /**
     * @brief Desequipa o item do jogador, revertendo seus efeitos e devolvendo-o ao inventario.
     * @param jogador Jogador que desequipara o item.
     */
    virtual void desequipar(shared_ptr<Jogador> jogador) = 0;

    /**
     * @brief Representacao textual do item.
     * @return Nome do item como string.
     */
    virtual string str() const{
        return nomeItem;
    }
    virtual ~Item() = default;
};

// --------------- CLASSE INVENTARIO ---------------
// Composicao: o Inventario guarda uma lista de Item (shared_ptr) e controla a capacidade total

/**
 * @brief Gerencia a colecao de itens de um Jogador.
 *
 * Usa composicao: o Inventario guarda uma lista de shared_ptr<Item> e controla
 * a capacidade total em slots. Consumiveis com o mesmo nome sao empilhados
 * (cada 9 unidades ocupa 1 slot).
 */
class Inventario{
public:
    vector<shared_ptr<Item>> itens;
    int capacidade;

    /**
     * @brief Constroi o inventario com a capacidade especificada.
     * @param capacidade Numero maximo de slots (padrao 20).
     */
    Inventario(int capacidade = 20);
    /**
     * @brief Adiciona um item ao inventario, empilhando se for consumivel de mesmo nome.
     * @param item Item a ser adicionado.
     * @return true se adicionado com sucesso, false se o inventario estava lotado.
     * @throws InventarioLotadoException se nao houver espaco disponivel.
     */
    bool adicionarItem(shared_ptr<Item> item);

    /**
     * @brief Remove uma unidade do item com o nome especificado.
     * @param nomeItem Nome do item a remover.
     * @return true se removido com sucesso.
     * @throws ItemNaoEncontradoException se o item nao existir no inventario.
     */
    bool removerItem(const string &nomeItem);
    /**
     * @brief Exibe todos os itens do inventario no console.
     */
    void listarItens();

   /**
     * @brief Busca e retorna um item pelo nome.
     * @param nomeItem Nome do item desejado.
     * @return shared_ptr para o item encontrado.
     * @throws ItemNaoEncontradoException se o item nao existir no inventario.
     */
    shared_ptr<Item> buscarItens(const string &nomeItem);
};

// -------------- CLASSE ARMA -----------------
// Item equipavel que aumenta o dano do jogador; ao equipar, e removida do inventario
// e ao desequipar, retorna ao inventario

/**
 * @brief Item equipavel que aumenta o dano do jogador.
 *
 * Ao equipar, e removida do inventario e a EstrategiaAtaque do jogador
 * muda para AtaqueComArma. Ao desequipar, retorna ao inventario e a
 * estrategia volta para AtaqueDesarmado.
 */
class Arma : public Item{
public:
    int dano;       ///< Dano adicional concedido ao jogador enquanto equipada.

    /**
     * @brief Constroi uma Arma com seus atributos.
     * @param nomeItem Nome da arma.
     * @param valor    Valor em ouro.
     * @param espaco   Slots ocupados no inventario.
     * @param dano     Dano adicional ao equipar.
     */
    Arma(string nomeItem, int valor, int espaco, int dano) : Item(nomeItem, valor, espaco){
        this->quantidade = 1;
        this->dano = dano;
    }

    /**
     * @brief Equipa a arma no jogador, aumentando seu dano e trocando a estrategia de ataque.
     * @param jogador Jogador que equipara a arma.
     */
    void equipar(shared_ptr<Jogador> jogador) override;    // Implementado em Itens.cpp (precisa de Jogador completo)

    /**
     * @brief Desequipa a arma do jogador, revertendo dano e estrategia de ataque.
     * @param jogador Jogador que desequipara a arma.
     */
    void desequipar(shared_ptr<Jogador> jogador) override; // Implementado em Itens.cpp

    /**
     * @brief Representacao textual da arma (nome, valor, espaco, dano).
     * @return String formatada com os atributos da arma.
     */
    string str() const override{
        stringstream ss;
        ss << this->nomeItem << ", " << this->valor << ", " << this->espaco << ". " << this->dano;
        return ss.str();
    }

private:
    shared_ptr<Item> shared_from_this_item(){
        return shared_ptr<Item>(this, [](Item *) {});
    }
};

// --------------- PADRAO ADAPTER: ARMA ANTIGA ---------------
// Simula uma arma vinda de um sistema/biblioteca legada, com interface incompativel com a atual.
// ArmaAntiga NAO herda de Item de proposito, e usa nomes diferentes (vestir/tirar em vez de
// equipar/desequipar, forcaArma em vez de dano) -- e exatamente esse tipo de incompatibilidade
// que o Adapter existe para resolver, sem precisar reescrever ArmaAntiga nem o sistema de Item


/**
 * @brief Representa uma arma de sistema legado com interface incompativel.
 *
 * ArmaAntiga nao herda de Item de proposito: usa nomes diferentes
 * (vestir/tirar em vez de equipar/desequipar, forcaArma em vez de dano).
 * Esta incompatibilidade e exatamente o que o padrao Adapter resolve,
 * sem precisar reescrever esta classe nem o sistema de Item atual.
 */
class ArmaAntiga{
public:
    string nomeArma;    ///< Nome da arma no sistema legado.
    int forcaArma;      ///< Equivalente ao "dano" da Arma atual, com nome diferente de proposito.

    /**
     * @brief Constroi uma ArmaAntiga com nome e forca.
     * @param nomeArma  Nome da arma.
     * @param forcaArma Forca (dano) da arma.
     */
    ArmaAntiga(string nomeArma, int forcaArma){
        this->nomeArma = nomeArma;
        this->forcaArma = forcaArma;
    }

    // Interface antiga: vestir/tirar, recebendo o nome do jogador em vez do shared_ptr<Jogador>

    /**
     * @brief Interface legada: veste a arma no jogador informado pelo nome.
     * @param nomeJogador Nome do jogador que esta vestindo a arma.
     */
    void vestir(string nomeJogador){
        cout << "[Sistema Antigo] " << nomeJogador << " vestiu " << this->nomeArma << " (forca " << this->forcaArma << ")" << endl;
    }

   /**
     * @brief Interface legada: tira a arma do jogador informado pelo nome.
     * @param nomeJogador Nome do jogador que esta tirando a arma.
     */
    void tirar(string nomeJogador){
        cout << "[Sistema Antigo] " << nomeJogador << " tirou " << this->nomeArma << endl;
    }
};

// --------------- PADRAO ADAPTER: ADAPTADOR DA ARMA ANTIGA ---------------
// AdaptadorArma "traduz" a interface de ArmaAntiga para a interface de Item que o jogo espera.
// Ele herda de Item (para se encaixar em qualquer lugar que espera um Item, ex: Inventario)
// e guarda uma ArmaAntiga por dentro (composicao), chamando vestir()/tirar() quando
// equipar()/desequipar() forem chamados -- isso e o Adapter: o resto do jogo nem sabe
// que por baixo existe uma ArmaAntiga com metodos de nome diferente


/**
 * @brief Adapter que traduz ArmaAntiga para a interface Item esperada pelo jogo.
 *
 * Herda de Item (para se encaixar em qualquer lugar que espera um Item, ex: Inventario)
 * e guarda uma ArmaAntiga internamente por composicao. Ao receber equipar()/desequipar(),
 * delega para vestir()/tirar() da ArmaAntiga. O resto do jogo nao precisa saber que
 * por baixo existe uma interface diferente.
 */
class AdaptadorArma : public Item{
private:
// O objeto de interface incompativel que esta sendo adaptado
    shared_ptr<ArmaAntiga> armaAntiga;  ///< Objeto legado sendo adaptado.

public:
    /**
     * @brief Constroi o adapter a partir de uma ArmaAntiga existente.
     * @param armaAntiga Ponteiro para a arma legada a ser adaptada.
     * @param valor      Valor em ouro do item adaptado.
     * @param espaco     Slots ocupados no inventario.
     */
    AdaptadorArma(shared_ptr<ArmaAntiga> armaAntiga, int valor, int espaco)
        : Item(armaAntiga->nomeArma, valor, espaco){
        this->armaAntiga = armaAntiga;
        this->quantidade = 1;
    }

    /**
     * @brief Equipa a arma antiga traduzindo para a interface atual.
     * @param jogador Jogador que equipara a arma.
     */
    void equipar(shared_ptr<Jogador> jogador) override;

    /**
     * @brief Desequipa a arma antiga traduzindo para a interface atual.
     * @param jogador Jogador que desequipara a arma.
     */
    void desequipar(shared_ptr<Jogador> jogador) override;

    /**
     * @brief Representacao textual do adapter (nome, valor, espaco, forca da arma antiga).
     * @return String formatada com os atributos.
     */
    string str() const override{
        stringstream ss;
        ss << this->nomeItem << ", " << this->valor << ", " << this->espaco << ". " << this->armaAntiga->forcaArma;
        return ss.str();
    }

private:
    shared_ptr<Item> shared_from_this_item(){
        return shared_ptr<Item>(this, [](Item *) {});
    }
};

// --------------- CLASSE ARMADURA ----------------
// Item equipavel que aumenta a defesa total do jogador; funciona igual a Arma
// (sai do inventario ao equipar e volta ao desequipar)

/**
 * @brief Item equipavel que aumenta a defesa total do jogador.
 *
 * Funciona igual a Arma: sai do inventario ao equipar e volta ao desequipar.
 */
class Armadura : public Item{
public:
    int defesa;     ///< Bonus de defesa concedido ao jogador enquanto equipada.

    /**
     * @brief Constroi uma Armadura com seus atributos.
     * @param nomeItem Nome da armadura.
     * @param valor    Valor em ouro.
     * @param espaco   Slots ocupados no inventario.
     * @param defesa   Bonus de defesa ao equipar.
     */
    Armadura(string nomeItem, int valor, int espaco, int defesa) : Item(nomeItem, valor, espaco){
        this->quantidade = 1;
        this->defesa = defesa;      
    }

    /**
     * @brief Equipa a armadura no jogador, aumentando sua defesa total.
     * @param jogador Jogador que equipara a armadura.
     */
    void equipar(shared_ptr<Jogador> jogador) override;

    /**
     * @brief Desequipa a armadura do jogador, revertendo o bonus de defesa.
     * @param jogador Jogador que desequipara a armadura.
     */
    void desequipar(shared_ptr<Jogador> jogador) override;

    /**
     * @brief Representacao textual da armadura (nome, valor, espaco, defesa).
     * @return String formatada com os atributos da armadura.
     */
    string str() const override{
        stringstream ss;
        ss << this->nomeItem << ", " << this->valor << ", " << this->espaco << ", " << this->defesa;
        return ss.str();
    }

private:
    shared_ptr<Item> shared_from_this_item(){
        return shared_ptr<Item>(this, [](Item *) {});
    }
};

// ------------- CLASSE CONSUMIVEIS (BASE) ---------------------
// Classe base para todos os itens consumiveis (pocoes, orbes)
// usarItem() e sobrecarregado para diferentes alvos: jogador, dois jogadores, ou inimigo


/**
 * @brief Classe base para todos os itens consumiveis (pocoes, orbes).
 *
 * usarItem() e sobrecarregado para tres contextos diferentes:
 * - usuario e alvo (cura/ressureicao entre jogadores)
 * - so usuario (recuperar mana)
 * - usuario e inimigo (pocao de dano elemental)
 */
class Consumiveis : public Item{
public:

    /**
     * @brief Constroi um Consumivel com seus atributos e quantidade inicial.
     * @param nomeItem  Nome do consumivel.
     * @param valor     Valor em ouro.
     * @param espaco    Slots ocupados no inventario.
     * @param quantidade Quantidade inicial empilhada.
     */
    Consumiveis(string nomeItem, int valor, int espaco, int quantidade) : Item(nomeItem, valor, espaco){
        this->quantidade = quantidade;
    }

    void equipar(shared_ptr<Jogador> jogador) override{}
    void desequipar(shared_ptr<Jogador> jogador) override{}

    /**
     * @brief Usa o consumivel tendo um jogador como alvo (ex: pocao de cura, orbe de ressureicao).
     * @param usuario Jogador que esta usando o item.
     * @param alvo    Jogador alvo do efeito.
     * @return true se o item foi usado com sucesso.
     */
    virtual bool usarItem(shared_ptr<Jogador> usuario, shared_ptr<Jogador> alvo) { return false; }

    /**
     * @brief Usa o consumivel sem alvo externo (ex: pocao de mana).
     * @param usuario Jogador que esta usando o item.
     * @return true se o item foi usado com sucesso.
     */
    virtual bool usarItem(shared_ptr<Jogador> usuario) { return false; }

    /**
     * @brief Usa o consumivel contra um inimigo (ex: pocao de dano elemental).
     * @param usuario Jogador que esta usando o item.
     * @param alvo    Inimigo que recebera o efeito.
     * @return true se o item foi usado com sucesso.
     */
    virtual bool usarItem(shared_ptr<Jogador> usuario, shared_ptr<Inimigo> alvo) { return false; }

    /**
     * @brief Representacao textual do consumivel (nome, valor, espaco, quantidade).
     * @return String formatada com os atributos.
     */
    string str() const override{
        stringstream ss;
        ss << this->nomeItem << ", " << this->valor << ", " << this->espaco << ". " << this->quantidade;
        return ss.str();
    }
};

// ------------------ CONSUMIVEIS CONCRETOS -------------------

/**
 * @brief Pocao que restaura pontos de vida de um jogador alvo.
 */
class PocaoVida : public Consumiveis{
public:

    /** @brief Constroi a pocao com a quantidade inicial especificada. */
    PocaoVida(int quantidade = 0) : Consumiveis("Pocao de Vida", 60, 1, quantidade) {}

    /**
     * @brief Usa a pocao para curar o jogador alvo.
     * @param usuario Jogador que esta usando a pocao.
     * @param alvo    Jogador que sera curado.
     * @return true se a pocao foi usada com sucesso.
     * @throws RecursoEsgotadoException se a quantidade for zero.
     */
    bool usarItem(shared_ptr<Jogador> usuario, shared_ptr<Jogador> alvo) override; // Implementado em Itens.cpp
};

/**
 * @brief Pocao que restaura mana do usuario.
 */
class PocaoMana : public Consumiveis{
public:

    /** @brief Constroi a pocao com a quantidade inicial especificada. */
    PocaoMana(int quantidade = 0) : Consumiveis("Pocao de Mana", 60, 1, quantidade) {}

    /**
     * @brief Usa a pocao para restaurar mana do usuario.
     * @param usuario Jogador que tera a mana restaurada.
     * @return true se a pocao foi usada com sucesso.
     * @throws RecursoEsgotadoException se a quantidade for zero.
     */
    bool usarItem(shared_ptr<Jogador> usuario) override;
};


/**
 * @brief Pocao de dano elemental que pode ser usada contra jogadores ou inimigos.
 */
class PocaoDanoElemental : public Consumiveis{
public:
    int dano;   ///< Dano causado pelo elemento da pocao.

    /**
     * @brief Constroi a pocao elemental com seus atributos.
     * @param nomeItem  Nome da pocao.
     * @param valor     Valor em ouro.
     * @param espaco    Slots ocupados.
     * @param quantidade Quantidade inicial.
     * @param dano      Dano causado ao usar.
     */
    PocaoDanoElemental(string nomeItem, int valor, int espaco, int quantidade, int dano)
        : Consumiveis(nomeItem, valor, espaco, quantidade){
        this->dano = dano;
    }

    /**
     * @brief Aplica o dano elemental em um jogador alvo.
     * @param usuario Jogador que esta lancando a pocao.
     * @param alvo    Jogador que recebera o dano.
     * @return true se a pocao foi usada com sucesso.
     */
    bool usarItem(shared_ptr<Jogador> usuario, shared_ptr<Jogador> alvo) override;

     /**
     * @brief Aplica o dano elemental em um inimigo.
     * @param usuario Jogador que esta lancando a pocao.
     * @param alvo    Inimigo que recebera o dano.
     * @return true se a pocao foi usada com sucesso.
     */
    bool usarItem(shared_ptr<Jogador> usuario, shared_ptr<Inimigo> alvo) override;
};

// Pocoes de dano separadas por elemento; cada uma define nome, valor, espaco e dano proprios

/** @brief Pocao de fogo: 50 de dano. */
class DanoFogo : public PocaoDanoElemental{
public:
    DanoFogo(int quantidade = 0) : PocaoDanoElemental("Pocao de Fogo", 50, 1, quantidade, 50) {}
};

/** @brief Pocao de gelo: 30 de dano. */
class DanoGelo : public PocaoDanoElemental{
public:
    DanoGelo(int quantidade = 0) : PocaoDanoElemental("Pocao de Gelo", 40, 1, quantidade, 30) {}
};

/** @brief Pocao de relampago: 70 de dano, ocupa 2 slots. */
class DanoRelampago : public PocaoDanoElemental{
public:
    DanoRelampago(int quantidade = 0) : PocaoDanoElemental("Pocao de Relampago", 60, 2, quantidade, 70) {}
};

/** @brief Pocao radiante: 50 de dano, item raro (999 de ouro). */
class DanoRadiante : public PocaoDanoElemental{
public:
    DanoRadiante(int quantidade = 0) : PocaoDanoElemental("Pocao Radiante", 999, 1, quantidade, 50) {}
};

/** @brief Pocao venenosa: 40 de dano. */
class DanoVenenoso : public PocaoDanoElemental{
public:
    DanoVenenoso(int quantidade = 0) : PocaoDanoElemental("Pocao Venenosa", 100, 1, quantidade, 40) {}
};

/** @brief Orbe que ressuscita um jogador morto. */
class OrbeRessureicao : public Consumiveis{
public:
    /** @brief Constroi o orbe com a quantidade inicial especificada. */
    OrbeRessureicao(int quantidade = 0) : Consumiveis("Orbe da Ressureicao", 1000, 3, quantidade) {}

    /**
     * @brief Ressuscita o jogador alvo, restaurando parte de seu HP.
     * @param usuario Jogador que esta usando o orbe.
     * @param alvo    Jogador morto que sera ressuscitado.
     * @return true se o orbe foi usado com sucesso.
     * @throws RecursoEsgotadoException se a quantidade for zero.
     */
    bool usarItem(shared_ptr<Jogador> usuario, shared_ptr<Jogador> alvo) override;
};

// ------------- ITEM GENERICO -----------------
// Item sem funcionalidade de equipar/desequipar; usado para itens inuteis como a Pedra Inutil
// criada pelo Artifice quando falha ao criar algo util

/**
 * @brief Item sem funcionalidade especial de equipar/desequipar.
 *
 * Usado para itens inuteis, como a Pedra Inutil criada pelo Artifice
 * quando falha ao tentar fabricar algo util.
 */
class ItemGenerico : public Item{
public:

    /**
     * @brief Constroi um ItemGenerico com os atributos fornecidos.
     * @param nomeItem  Nome do item.
     * @param valor     Valor em ouro (padrao 0).
     * @param espaco    Slots ocupados (padrao 1).
     * @param quantidade Quantidade (padrao 1).
     */
    ItemGenerico(string nomeItem, int valor = 0, int espaco = 1, int quantidade = 1)
        : Item(nomeItem, valor, espaco){
        this->quantidade = quantidade;
    }

    void equipar(shared_ptr<Jogador> jogador) override{}
    void desequipar(shared_ptr<Jogador> jogador) override{}

    /**
     * @brief Representacao textual do item generico.
     * @return Nome do item com sufixo " inutil".
     */
    string str() const override{
        return this->nomeItem + " inutil";
    }
};

#endif
