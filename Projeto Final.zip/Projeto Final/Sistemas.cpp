#include "Sistemas.h"

// Inicializacao dos ponteiros estaticos dos Singletons (precisa estar em exatamente um .cpp)
Logger *Logger::_instancia = nullptr;
GerenciadorDeJogo *GerenciadorDeJogo::_instancia = nullptr;

// ----------------- IMPLEMENTACAO: ARTIFICE::CRIARITEM ------------------
// Tenta criar um item do tipo solicitado; tem 30% de chance de criar uma Pedra Inutil
// Fica aqui (Sistemas.cpp) pois usa CriacaoItens, que e definido em Sistemas.h
shared_ptr<Item> Artifice::criarItem(string tipo, int quantidade){
    if (this->morto == true){
        cout << this->getNome() << " esta morto e nao pode criar itens" << endl;
        return nullptr;
    }

    if (randint(0, 100) < 30){
        shared_ptr<Item> pedra = make_shared<ItemGenerico>("Pedra Inutil", 0, 1);
        this->inventario.adicionarItem(pedra);
        cout << this->getNome() << " criou uma pedra inutil, parabens =) " << endl;
        return pedra;
    }

    shared_ptr<Item> item = CriacaoItens::criarPocao(tipo, quantidade);
    if (item == nullptr)
        item = CriacaoItens::criarArma(tipo);

    if (item == nullptr){
        throw AcaoInvalidaException(this->getNome() + " nao sabe como criar " + tipo);
    }

    this->inventario.adicionarItem(item);
    cout << "Voce criou " << item->nomeItem << " com sucesso" << endl;
    return item;
}
