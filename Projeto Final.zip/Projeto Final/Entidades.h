#ifndef ENTIDADES_H
#define ENTIDADES_H

#include <iostream>
#include <string>
#include <map>
#include <memory>
#include <sstream>
#include "Excecoes.h"
#include "Itens.h"
#include "Utils.h"
using namespace std;

// Forward declarations cruzadas: Jogador e Inimigo se atacam mutuamente,
// e Habilidade/EstrategiaAtaque precisam de ambos so por ponteiro

/**
 * @file Entidades.h
 * @brief Classes de jogadores, inimigos, habilidades e o padrao Strategy de ataque.
 *
 * Define a hierarquia abstrata Jogador e Inimigo com suas subclasses concretas,
 * as habilidades de cada classe de jogador e o padrao Strategy que determina
 * como um Jogador ataca dependendo de ter ou nao uma arma equipada.
 */
 
// Forward declarations cruzadas: Jogador e Inimigo se atacam mutuamente,
// e Habilidade/EstrategiaAtaque precisam de ambos so por ponteiro
class Jogador;
class Inimigo;

// -------------- CLASSE HABILIDADE (BASE ABSTRATA) -----------------
// Define a interface comum de toda habilidade de classe (skill ativa)
// Cada classe de Jogador (Bruxo, Ladrao, Artifice, Guerreiro) tem a sua propria habilidade,
// que sobrescreve usar() com seu efeito especifico (Polimorfismo)
// custoMana e nome ficam na classe base pois toda habilidade tem essas duas coisas em comum (Abstracao)

/**
 * @brief Classe base abstrata para habilidades ativas dos jogadores.
 *
 * Cada classe de Jogador (Bruxo, Ladrao, Artifice, Guerreiro) tem sua propria
 * habilidade que sobrescreve usar() com efeito especifico (Polimorfismo).
 * O nome e custo de mana ficam na classe base pois toda habilidade os possui.
 */
class Habilidade{
protected:
    string __nome;      ///< Nome da habilidade exibido no menu de combate.
    int __custoMana;    ///< Quantidade de mana consumida ao usar a habilidade.

public:

    /**
     * @brief Constroi uma habilidade com nome e custo de mana.
     * @param nome      Nome da habilidade.
     * @param custoMana Mana consumida ao usar.
     */
    Habilidade(string nome, int custoMana){
        this->__nome = nome;
        this->__custoMana = custoMana;
    }

    /** @brief Retorna o nome da habilidade. */
    string getNome() const{
        return __nome;
    }

    /** @brief Retorna o custo de mana da habilidade. */
    int getCustoMana() const{
        return __custoMana;
    }

    // Usa a habilidade contra um inimigo; retorna true se conseguiu usar (tinha mana o suficiente)
    // O efeito de fato (dano, cura, buff, etc.) e decidido por cada subclasse

    /**
     * @brief Usa a habilidade contra um inimigo.
     *
     * Retorna true se a habilidade foi ativada com sucesso (havia mana suficiente).
     * O efeito concreto (dano, cura, buff, etc.) e definido por cada subclasse.
     *
     * @param usuario Jogador que esta usando a habilidade.
     * @param alvo    Inimigo que recebera o efeito.
     * @return true se havia mana suficiente e a habilidade foi usada.
     */
    virtual bool usar(shared_ptr<Jogador> usuario, shared_ptr<Inimigo> alvo) = 0;

    virtual ~Habilidade() = default;
};

// ------------------ HABILIDADES CONCRETAS -------------------
// Cada habilidade concreta pertence a uma classe de Jogador e define seu proprio efeito em usar()
// Implementadas em Entidades.cpp pois usam Logger::instancia() (definido em Sistemas.h)

/** @brief Habilidade do Bruxo: causa dano magico de fogo ao inimigo. Custo: 40 de mana.*/
class BolaDeFogo : public Habilidade{ // Habilidade do Bruxo
public:
    BolaDeFogo() : Habilidade("Bola de Fogo", 40){}

    /**
     * @brief Dispara uma bola de fogo no inimigo alvo.
     * @param usuario Bruxo que dispara a habilidade.
     * @param alvo    Inimigo que recebe o dano.
     * @return true se havia mana suficiente.
     */
    bool usar(shared_ptr<Jogador> usuario, shared_ptr<Inimigo> alvo) override;
};

/** @brief Habilidade do Ladrao: ataque furtivo com bonus de dano. Custo: 20 de mana.*/
class GolpeFurtivo : public Habilidade{ // Habilidade do Ladrao
public:
    GolpeFurtivo() : Habilidade("Golpe Furtivo", 20){}

     /**
     * @brief Aplica um golpe furtivo com bonus de dano no inimigo.
     * @param usuario Ladrao que executa o golpe.
     * @param alvo    Inimigo que recebe o dano.
     * @return true se havia mana suficiente.
     */
    bool usar(shared_ptr<Jogador> usuario, shared_ptr<Inimigo> alvo) override;
};

/** @brief Habilidade do Artifice: lanca uma granada artesanal no inimigo. Custo: 30 de mana.*/
class GranadaImprovisada : public Habilidade{ // Habilidade do Artifice
public:
    GranadaImprovisada() : Habilidade("Granada Improvisada", 30){}

    /**
     * @brief Lanca uma granada improvisada no inimigo.
     * @param usuario Artifice que lanca a granada.
     * @param alvo    Inimigo que recebe o dano de explosao.
     * @return true se havia mana suficiente.
     */
    bool usar(shared_ptr<Jogador> usuario, shared_ptr<Inimigo> alvo) override;
};

/** @brief Habilidade do Guerreiro: golpe fisico poderoso. Custo: 10 de mana.*/
class GolpeBrutal : public Habilidade{ // Habilidade do Guerreiro
public:
    GolpeBrutal() : Habilidade("Golpe Brutal", 10){}

    /**
     * @brief Desfere um golpe brutal no inimigo.
     * @param usuario Guerreiro que executa o golpe.
     * @param alvo    Inimigo que recebe o dano.
     * @return true se havia mana suficiente.
     */
    bool usar(shared_ptr<Jogador> usuario, shared_ptr<Inimigo> alvo) override;
};

// --------------- PADRAO STRATEGY: ESTRATEGIA DE ATAQUE ---------------
// Antes, cada atacar() tinha um if (armaEquipada != nullptr) {...} else {murro/tapa} no meio do metodo
// Com Strategy, essa escolha de "como atacar" vira um objeto separado e intercambiavel:
// o Jogador guarda uma EstrategiaAtaque e troca o objeto quando equipa/desequipa arma,
// sem precisar mudar a classe do personagem nem duplicar o if/else em cada atacar()

/**
 * @brief Interface do padrao Strategy para o ataque dos jogadores.
 *
 * Antes, cada atacar() tinha um if (armaEquipada != nullptr) no meio do metodo.
 * Com Strategy, essa escolha de "como atacar" vira um objeto separado e intercambiavel:
 * o Jogador guarda uma EstrategiaAtaque e troca o objeto quando equipa ou desequipa arma,
 * sem precisar mudar a classe do personagem nem duplicar o if/else em cada atacar().
 */
class EstrategiaAtaque{
public:

    /**
     * @brief Executa o ataque do jogador contra outro jogador.
     * @param atacante Jogador que esta atacando.
     * @param alvo     Jogador alvo do ataque.
     * @return Dano causado.
     */
    virtual int executar(shared_ptr<Jogador> atacante, shared_ptr<Jogador> alvo) = 0;

    /**
     * @brief Executa o ataque do jogador contra um inimigo.
     * @param atacante Jogador que esta atacando.
     * @param alvo     Inimigo alvo do ataque.
     * @return Dano causado.
     */
    virtual int executar(shared_ptr<Jogador> atacante, shared_ptr<Inimigo> alvo) = 0;
    virtual ~EstrategiaAtaque() = default;
};

// Estrategia usada quando o Jogador tem uma arma equipada

/**
 * @brief Estrategia de ataque usada quando o Jogador tem uma arma equipada.
 *
 * Calcula o dano com base no atributo de dano da arma equipada.
 */
class AtaqueComArma : public EstrategiaAtaque{
public:
    int executar(shared_ptr<Jogador> atacante, shared_ptr<Jogador> alvo) override;
    int executar(shared_ptr<Jogador> atacante, shared_ptr<Inimigo> alvo) override;
};

// Estrategia usada quando o Jogador NAO tem arma equipada (murro, tapa, ou pedra do Artifice)

/**
 * @brief Estrategia de ataque usada quando o Jogador nao tem arma equipada.
 *
 * Usa murro, tapa ou pedra (no caso do Artifice) como ataque fisico basico.
 */
class AtaqueDesarmado : public EstrategiaAtaque{
public:
    int executar(shared_ptr<Jogador> atacante, shared_ptr<Jogador> alvo) override;
    int executar(shared_ptr<Jogador> atacante, shared_ptr<Inimigo> alvo) override;
};

// -------------- CLASSE JOGADOR (BASE ABSTRATA) ----------------------
// Classe base para todos os tipos de jogadores (Bruxo, Ladrao, Artifice, Guerreiro)
// Herda de enable_shared_from_this para poder gerar shared_ptr de si mesmo com seguranca
// Os atributos de nome, level e hp sao privados e acessados via getters/setters

/**
 * @brief Classe base abstrata para todos os tipos de jogadores.
 *
 * Herda de enable_shared_from_this para poder gerar shared_ptr de si mesmo com seguranca.
 * Os atributos de nome, level e hp sao privados e acessados via getters/setters.
 * Subclasses concretas: Bruxo, Ladrao, Artifice, Guerreiro.
 */
class Jogador : public enable_shared_from_this<Jogador>{
private:
    string __nome;      ///< Nome do jogador (privado, acessado via getNome/setNome).
    int __level;        ///< Level atual do jogador.
    int __hp;       ///< Pontos de vida atuais.
    int __hpMax;        ///< Pontos de vida maximos.

public:
    int xp;     ///< Experiencia atual do jogador.
    int xpMax;       ///< Experiencia necessaria para subir de level.
    bool morto;     ///< true se o jogador esta morto.
    shared_ptr<Raca> raca;      ///< Raca do jogador (define bonus de atributos).

    Inventario inventario;      ///< Inventario pessoal do jogador.
    shared_ptr<Item> armaEquipada;      ///< Arma atualmente equipada (nullptr se nenhuma).
    int armaduraBase;       ///< Defesa base da classe (sem armadura equipada).
    shared_ptr<Item> armaduraEquipada;      ///< Armadura atualmente equipada (nullptr se nenhuma).
    int defesaTotal;        ///< Defesa total (base + armadura).
    string classe;      ///< Nome da classe do jogador (ex: "Bruxo").
    int dano;        ///< Dano base do jogador (sem arma equipada).
    int mana;       ///< Mana atual do jogador.
    int furtividade;        ///< Bonus de furtividade (usado na tentativa de fuga).
    shared_ptr<Habilidade> habilidade;      ///< Habilidade ativa exclusiva da classe.
    shared_ptr<EstrategiaAtaque> estrategiaAtaque;      ///< Estrategia de ataque atual (com ou sem arma).

    /**
     * @brief Constroi um Jogador com os atributos fundamentais.
     * @param nome     Nome do personagem.
     * @param level    Level inicial.
     * @param raca     Raca que define bonus de atributos.
     * @param hp       Pontos de vida iniciais e maximos.
     * @param xp       Experiencia inicial.
     * @param armadura Defesa base da classe (padrao 0).
     */
    Jogador(string nome, int level, shared_ptr<Raca> raca, int hp, int xp, int armadura = 0)
        : inventario(){
        this->__nome = nome;
        this->__level = level;
        this->__hp = hp;
        this->__hpMax = hp;
        this->xp = xp;
        this->xpMax = 100;
        this->morto = false;
        this->raca = raca;
        this->armaEquipada = nullptr;
        this->armaduraBase = armadura;
        this->armaduraEquipada = nullptr;
        this->defesaTotal = 0;
        this->dano = 0;
        this->mana = 0;
        this->furtividade = 0;
        this->habilidade = nullptr;
        this->estrategiaAtaque = nullptr;
    }

    /** @brief Retorna o nome do jogador. */
    string getNome() const{ return __nome; }

    /** @brief Retorna o level atual. */
    int getLevel() const{ return __level; }

     /** @brief Retorna o HP atual. */
    int getHP() const{ return __hp; }

    /** @brief Retorna o HP maximo. */
    int getHPMax() const{ return __hpMax; }

    /**
     * @brief Calcula e retorna a defesa total (base + armadura equipada).
     * @return Valor total de defesa.
     */
    int getArmadura(); // Implementado em Itens.cpp, pois precisa de Armadura completa

     /** @brief Define o nome do jogador. */
    void setNome(string nome){ this->__nome = nome; }

    /** @brief Define o level do jogador. */
    void setLevel(int level){ this->__level = level; }

    /** @brief Define o HP atual do jogador. */
    void setHP(int hp){ this->__hp = hp; }

    /** @brief Define o HP maximo do jogador. */
    void setHPMax(int hpMax){ this->__hpMax = hpMax; }

    /**
     * @brief Exibe o status completo do jogador no console.
     * Implementado por cada subclasse.
     */
    virtual void exibirStatus() = 0;

    /**
     * @brief Aplica dano ao jogador, marcando-o como morto se HP chegar a zero.
     * @param dano    Quantidade de dano a receber.
     * @param matador Ponteiro generico para quem causou a morte (opcional).
     */
    virtual void receberDano(int dano, shared_ptr<void> matador = nullptr){
        this->__hp -= dano;
        if (this->__hp <= 0){
            this->__hp = 0;
            this->morto = true;
            cout << "Game Over para " << this->__nome << endl;
        }
    }

    /**
     * @brief Cura o jogador pelo valor especificado, limitado ao HP maximo.
     * @param cura Quantidade de HP a restaurar.
     * @return true se a cura foi aplicada, false se o jogador estava com HP cheio ou morto.
     */
    bool curar(int cura){
        if (this->__hp == this->__hpMax){
            cout << "Nao é possivel se curar, vida já esta cheia" << endl;
            return false;
        }
        else if (this->__hp <= 0){
            cout << this->__nome << " esta morto, ache um orbe da resurreicao" << endl;
            return false;
        }
        this->__hp += cura;
        if (this->__hp > this->__hpMax){
            this->__hp = this->__hpMax;
            cout << "Vida totalmente restaurada" << endl;
        }
        return true;
    }

    /**
     * @brief Adiciona experiencia ao jogador, subindo de level se atingir xpMax.
     * @param experiencia Quantidade de XP a ganhar.
     * @return true se o jogador subiu de level.
     */
    bool ganharXP(int experiencia); // Implementado em Entidades.cpp (usa GerenciadorDeJogo, de Sistemas.h)

    /**
     * @brief Ataca outro jogador usando a EstrategiaAtaque atual.
     * @param alvo Jogador alvo do ataque.
     * @return Dano causado.
     */
    virtual int atacar(shared_ptr<Jogador> alvo) = 0;

    /**
     * @brief Ataca um inimigo usando a EstrategiaAtaque atual.
     * @param alvo Inimigo alvo do ataque.
     * @return Dano causado.
     */
    virtual int atacar(shared_ptr<Inimigo> alvo) = 0;

    /**
     * @brief Serializa o estado do jogador em um mapa chave-valor para save/load.
     * @return Mapa com os dados do jogador.
     */
    virtual map<string, string> serializaDicionario();

    /**
     * @brief Reconstroi um Jogador a partir de um mapa chave-valor carregado do save.
     * @param dados Mapa com os dados serializados.
     * @return shared_ptr para o Jogador recriado, ou nullptr se a classe for invalida.
     */
    static shared_ptr<Jogador> desserializaDicionario(const map<string, string> &dados);

    /**
     * @brief Retorna o nome da classe concreta do jogador (ex: "Bruxo").
     * @return Nome da classe.
     */
    virtual string nomeClasse() const = 0;

    /**
     * @brief Representacao textual completa do jogador.
     * @return String com classe, nome, raca, level, HP e XP.
     */
    virtual string str() const{
        stringstream ss;
        ss << "Classe: " << nomeClasse() << ", Nome: " << __nome << ", Raca: " << raca->str()
           << ", Level: " << __level << ", HP: " << __hp << "/" << __hpMax << ", XP: " << xp << "/" << xpMax;
        return ss.str();
    }

    virtual ~Jogador() = default;
};

// Sobrecarga do operador << para exibir jogadores diretamente com cout

/**
 * @brief Sobrecarga do operador << para exibir jogadores diretamente com cout.
 * @param os      Stream de saida.
 * @param jogador Jogador a ser exibido.
 * @return Referencia ao stream de saida.
 */
ostream &operator<<(ostream &os, const shared_ptr<Jogador> &jogador);

// -------------- CLASSE INIMIGO (BASE ABSTRATA) ----------------
// Classe base para os inimigos (Dragao, Basilisco, Saqueadores)

/**
 * @brief Classe base abstrata para todos os inimigos do jogo.
 *
 * Subclasses concretas: Dragao, Basilisco, Saqueadores.
 * Herda de enable_shared_from_this para permitir shared_ptr de si mesmo com seguranca.
 */
class Inimigo : public enable_shared_from_this<Inimigo>{
private:
    string __nome; ///< Nome do inimigo.
    int __hp;      ///< Pontos de vida atuais.
    int __hpMax;   ///< Pontos de vida maximos.
 
public:
    int dano;            ///< Dano base do inimigo por ataque.
    int xpRecompensa;    ///< XP concedido ao grupo ao derrotar este inimigo.
    int ouroRecompensa;  ///< Ouro concedido ao grupo ao derrotar este inimigo.
    bool morto;          ///< true se o inimigo foi derrotado.
    int armadura;        ///< Reducao de dano recebido pelo inimigo.
    string estadoMonstro; ///< Chave usada no GerenciadorDeJogo para marcar se foi derrotado.

    /**
     * @brief Constroi um Inimigo com seus atributos basicos.
     * @param nome           Nome do inimigo.
     * @param hp             Pontos de vida.
     * @param dano           Dano por ataque.
     * @param xpRecompensa   XP de recompensa ao derrotar.
     * @param ouroRecompensa Ouro de recompensa ao derrotar.
     */
    Inimigo(string nome, int hp, int dano, int xpRecompensa, int ouroRecompensa){
        this->__nome = nome;
        this->__hp = hp;
        this->__hpMax = hp;
        this->dano = dano;
        this->xpRecompensa = xpRecompensa;
        this->ouroRecompensa = ouroRecompensa;
        this->morto = false;
        this->armadura = 1;
    }

    /** @brief Retorna o nome do inimigo. */
    string getNome() const{ return __nome; }

    /** @brief Retorna a armadura do inimigo. */
    int getArmadura() const{ return armadura; }
    
    /** @brief Retorna o HP atual. */
    int getHP() const{ return __hp; }

    /** @brief Retorna o HP maximo. */
    int getHPMax() const{ return __hpMax; }

    /** @brief Define o nome do inimigo. */
    void setNome(string nome){ this->__nome = nome; }

    /** @brief Define o HP atual do inimigo. */
    void setHP(int hp){ this->__hp = hp; }

    /** @brief Define o HP maximo do inimigo. */
    void setHPMax(int hpMax){ this->__hpMax = hpMax; }

    /**
     * @brief Ataca um jogador. Implementado por cada subclasse.
     * @param alvo Jogador alvo do ataque.
     * @return Dano causado.
     */
    virtual int atacar(shared_ptr<Jogador> alvo) = 0;

    /**
     * @brief Distribui recompensas de ouro ao jogador que derrotou o inimigo.
     * @param jogador Jogador que recebera as recompensas.
     */
    void droparRecompensas(shared_ptr<Jogador> jogador); // Implementado em Entidades.cpp

    /**
     * @brief Aplica dano ao inimigo, marcando-o como morto e dropando recompensas se HP zerar.
     * @param dano    Quantidade de dano a receber.
     * @param jogador Jogador que causou o dano (para distribuir recompensas ao matar).
     */
    void receberDano(int dano, shared_ptr<Jogador> jogador = nullptr){
        this->__hp -= dano;
        if (this->__hp <= 0){
            this->__hp = 0;
            this->morto = true;
            cout << this->getNome() << " foi derrotado!" << endl;
            if (jogador != nullptr){
                this->droparRecompensas(jogador);
            }
        }
    }

    virtual ~Inimigo() = default;
};

// --------------- CLASSES DE JOGADORES (CONCRETAS) ---------------
// Cada classe define atributos proprios e implementa atacar() com comportamento unico

/**
 * @brief Classe de jogador magico, especializado em dano magico e habilidades arcanas.
 *
 * Possui alto carisma e mana elevada. Usa foco arcano como arma padrao
 * (nao equipa arma convencional). Habilidade: BolaDeFogo.
 */
class Bruxo : public Jogador{
public:
    int carisma;        ///< Atributo de carisma do Bruxo (base 20 + bonus de raca).

    /**
     * @brief Constroi um Bruxo com os parametros fornecidos.
     * @param nome  Nome do personagem.
     * @param nivel Level inicial.
     * @param Raca  Raca que define bonus de atributos.
     * @param hp    HP inicial (padrao 150).
     * @param xp    XP inicial (padrao 0).
     */
    Bruxo(string nome, int nivel, shared_ptr<Raca> Raca, int hp = 150, int xp = 0)
        : Jogador(nome, nivel, Raca, hp, xp){
        this->classe = "Bruxo";
        this->mana = 100;
        this->carisma = 20 + Raca->bonusCarisma;
        this->habilidade = make_shared<BolaDeFogo>();
        // Nao colocado para equipar arma pois ele tem foco arcano que anda com ele
    }

    int atacar(shared_ptr<Jogador> alvo) override;
    int atacar(shared_ptr<Inimigo> alvo) override;

    void exibirStatus() override{
        cout << "Classe: " << this->classe << ", Nome: " << this->getNome() << ", Raca: " << this->raca->str() << ", Level: " << this->getLevel() << ", HP: " << this->getHP() << "/" << this->getHPMax() << ", XP: " << this->xp << "/" << this->xpMax << endl;
    }

    string nomeClasse() const override { return "Bruxo"; }
};

/**
 * @brief Classe de jogador agil, especializado em furtividade e ataques precisos.
 *
 * Possui bonus de furtividade que melhora a chance de fuga no combate.
 * Habilidade: GolpeFurtivo.
 */
class Ladrao : public Jogador{
public:
    int agilidade;      ///< Atributo de agilidade do Ladrao (base 15 + bonus de raca).

    /**
     * @brief Constroi um Ladrao com os parametros fornecidos.
     * @param nome  Nome do personagem.
     * @param nivel Level inicial.
     * @param Raca  Raca que define bonus de atributos.
     * @param hp    HP inicial (padrao 170).
     * @param xp    XP inicial (padrao 0).
     */
    Ladrao(string nome, int nivel, shared_ptr<Raca> Raca, int hp = 170, int xp = 0)
        : Jogador(nome, nivel, Raca, hp, xp){
        this->classe = "Ladrao";
        this->agilidade = 15 + Raca->bonusAgilidade;
        this->furtividade = 10;
        this->mana = 50;
        this->habilidade = make_shared<GolpeFurtivo>();
        this->estrategiaAtaque = make_shared<AtaqueDesarmado>();
    }

    int atacar(shared_ptr<Jogador> alvo) override;
    int atacar(shared_ptr<Inimigo> alvo) override;

    void exibirStatus() override{
        cout << "Classe: " << this->classe << ", Nome: " << this->getNome() << ", Raca: " << this->raca->str() << ", Level: " << this->getLevel() << ", HP: " << this->getHP() << "/" << this->getHPMax() << ", XP: " << this->xp << "/" << this->xpMax << endl;
    }

    string nomeClasse() const override { return "Ladrao"; }
};

/**
 * @brief Classe de jogador inventivo, capaz de criar itens durante a partida.
 *
 * Possui alta inteligencia e pode fabricar pocoes e itens via criarItem().
 * Habilidade: GranadaImprovisada.
 */
class Artifice : public Jogador{
public:
    int inteligencia;

     /**
     * @brief Constroi um Artifice com os parametros fornecidos.
     * @param nome  Nome do personagem.
     * @param nivel Level inicial.
     * @param Raca  Raca que define bonus de atributos.
     * @param hp    HP inicial (padrao 150).
     * @param xp    XP inicial (padrao 0).
     */
    Artifice(string nome, int nivel, shared_ptr<Raca> Raca, int hp = 150, int xp = 0)
        : Jogador(nome, nivel, Raca, hp, xp){
        this->classe = "Artifice";
        this->mana = 100;
        this->inteligencia = 20 + Raca->bonusInteligencia;
        this->habilidade = make_shared<GranadaImprovisada>();
        this->estrategiaAtaque = make_shared<AtaqueDesarmado>();
    }

    /**
     * @brief Fabrica um item do tipo especificado usando a inteligencia do Artifice.
     * @param tipo      Tipo do item a criar (ex: "pocao", "granada").
     * @param quantidade Quantidade a criar (padrao 1).
     * @return shared_ptr para o item criado, ou ItemGenerico se o tipo for invalido.
     * @throws AcaoInvalidaException se o tipo nao for reconhecido.
     */
    shared_ptr<Item> criarItem(string tipo, int quantidade = 1); // Implementado em Sistemas.cpp (usa AcaoInvalidaException ja incluso aqui)
    int atacar(shared_ptr<Jogador> alvo) override;
    int atacar(shared_ptr<Inimigo> alvo) override;

    void exibirStatus() override{
        cout << "Classe: " << this->classe << ", Nome: " << this->getNome() << ", Raca: " << this->raca->str() << ", Level: " << this->getLevel() << ", HP: " << this->getHP() << "/" << this->getHPMax() << ", XP: " << this->xp << "/" << this->xpMax << endl;
    }

    string nomeClasse() const override { return "Artifice"; }
};

/**
 * @brief Classe de jogador tanque, com alto HP e armadura base.
 *
 * Possui alta forca e resistencia natural a dano (armaduraBase = 5).
 * Habilidade: GolpeBrutal.
 */
class Guerreiro : public Jogador{
public:
    int forca;      ///< Atributo de forca do Guerreiro (base 20 + bonus de agilidade da raca).

     /**
     * @brief Constroi um Guerreiro com os parametros fornecidos.
     * @param nome  Nome do personagem.
     * @param nivel Level inicial.
     * @param Raca  Raca que define bonus de atributos.
     * @param hp    HP inicial (padrao 250).
     * @param xp    XP inicial (padrao 0).
     */
    Guerreiro(string nome, int nivel, shared_ptr<Raca> Raca, int hp = 250, int xp = 0)
        : Jogador(nome, nivel, Raca, hp, xp, 5){
        this->classe = "Guerreiro";
        this->forca = 20 + Raca->bonusAgilidade;
        this->mana = 30;
        this->habilidade = make_shared<GolpeBrutal>();
        this->estrategiaAtaque = make_shared<AtaqueDesarmado>();
    }

    int atacar(shared_ptr<Jogador> alvo) override;
    int atacar(shared_ptr<Inimigo> alvo) override;

    void exibirStatus() override{
        cout << "Classe: " << this->classe << ", Nome: " << this->getNome() << ", Raca: " << this->raca->str() << ", Level: " << this->getLevel() << ", HP: " << this->getHP() << "/" << this->getHPMax() << ", XP: " << this->xp << "/" << this->xpMax << endl;
    }

    string nomeClasse() const override { return "Guerreiro"; }
};

// ------------------- INIMIGOS CONCRETOS -----------------
// Cada inimigo define HP, dano, recompensas e a logica propria de ataque via atacar()
// estadoMonstro e a chave usada no Singleton GerenciadorDeJogo para marcar se o inimigo foi derrotado

/**
 * @brief Inimigo boss de alto HP e armadura elevada.
 *
 * HP: 1000, Dano: 30, Armadura: 7.
 * Recompensa: 100 XP + 200 ouro.
 */
class Dragao : public Inimigo{
public:
    Dragao() : Inimigo("Dragao", 1000, 30, 100, 200){
        this->armadura = 7;
        this->estadoMonstro = "dragaoMorto";
    }

    /**
     * @brief Ataca um jogador com garras e fogo.
     * @param alvo Jogador alvo do ataque.
     * @return Dano causado.
     */
    int atacar(shared_ptr<Jogador> alvo) override;
};

/**
 * @brief Inimigo de dificuldade intermediaria com armadura media.
 *
 * HP: 700, Dano: 25, Armadura: 5.
 * Recompensa: 80 XP + 120 ouro.
 */
class Basilisco : public Inimigo{
public:
    Basilisco() : Inimigo("Basilisco", 700, 25, 80, 120){
        this->armadura = 5;
        this->estadoMonstro = "dragaoMorto";
    }
    /**
     * @brief Ataca um jogador com mordida e veneno.
     * @param alvo Jogador alvo do ataque.
     * @return Dano causado.
     */
    int atacar(shared_ptr<Jogador> alvo) override;
};

/**
 * @brief Grupo de inimigos fracos, ideal para iniciantes.
 *
 * HP: 300, Dano: 15, Armadura: 1.
 * Recompensa: 30 XP + 100 ouro.
 */
class Saqueadores : public Inimigo{
public:
    Saqueadores() : Inimigo("Saqueadores", 300, 15, 30, 100){
        this->armadura = 1;
        this->estadoMonstro = "dragaoMorto";
    }
    /**
     * @brief Ataca um jogador com golpes de grupo.
     * @param alvo Jogador alvo do ataque.
     * @return Dano causado.
     */
    int atacar(shared_ptr<Jogador> alvo) override;
};

#endif
