#ifndef EXCECOES_H
#define EXCECOES_H

#include <string>
#include <exception>
using namespace std;
/*Comentarios legado
---------------- EXCECOES CUSTOMIZADAS DO JOGO -----------------
Antes, todo erro do jogo (inventario lotado, sem mana, sem grana, etc.) usava o mesmo
runtime_error generico, so mudando a mensagem. Agora cada situacao tem sua propria classe
de excecao, todas herdando de ExcecaoJogo (que por sua vez herda de exception), entao quem
pegar o erro pode tratar so um tipo especifico (catch (SemManaException&)) ou todos juntos
(catch (ExcecaoJogo&)), sem perder a informacao de qual problema realmente aconteceu

Classe base de toda excecao propria do jogo
Guarda a mensagem e implementa what(), igual as excecoes da biblioteca padrao fazem

Obs.: Substituido todos os codigos legado de cada tratamento de erro pelo doxygen
*/

//Comentarios com Doxygen:
/**
 * @file Excecoes.h
 * @brief Hierarquia de excecoes customizadas do jogo RPG.
 *
 * Antes, todo erro do jogo (inventario lotado, sem mana, sem grana, etc.) usava o mesmo
 * runtime_error generico, so mudando a mensagem. Agora cada situacao tem sua propria classe
 * de excecao, todas herdando de ExcecaoJogo (que por sua vez herda de exception), entao quem
 * pegar o erro pode tratar so um tipo especifico (catch (SemDinheiroException&)) ou todos juntos
 * (catch (ExcecaoJogo&)), sem perder a informacao de qual problema realmente aconteceu.
 */
 
/**
 * @brief Classe base de toda excecao propria do jogo.
 *
 * Guarda a mensagem e implementa what(), igual as excecoes da biblioteca padrao fazem.
 * Todas as excecoes do jogo herdam desta classe.
 */

class ExcecaoJogo : public exception{
protected:
    string mensagem;    //< Mensagem descritiva do erro

public:
    /**
     * @brief Constroi a excecao com uma mensagem descritiva.
     * @param mensagem Texto explicando o motivo do erro.
     */
    ExcecaoJogo(const string &mensagem){
        this->mensagem = mensagem;
    }

    /**
     * @brief Retorna a mensagem de erro como C-string.
     * @return Ponteiro para a string de erro.
     */
    const char *what() const noexcept override{
        return this->mensagem.c_str();
    }
};



/**
 * @brief Lancada quando o inventario nao tem mais espaco para receber um item novo.
 */
class InventarioLotadoException : public ExcecaoJogo{
public:
    /**
     * @brief Constroi a excecao com uma mensagem descritiva.
     * @param mensagem Texto explicando o motivo do erro.
     */
    InventarioLotadoException(const string &mensagem) : ExcecaoJogo(mensagem) {}
};

/**
 * @brief Lancada quando se busca ou remove um item que nao existe no inventario ou loja.
 */
class ItemNaoEncontradoException : public ExcecaoJogo{
public:
    /**
     * @brief Constroi a excecao com uma mensagem descritiva.
     * @param mensagem Texto explicando o motivo do erro.
     */
    ItemNaoEncontradoException(const string &mensagem) : ExcecaoJogo(mensagem) {}
};

/**
 * @brief Lancada quando uma pocao, orbe ou outro consumivel acabou e o jogador tenta usar de novo.
 */
class RecursoEsgotadoException : public ExcecaoJogo{
public:
    /**
     * @brief Constroi a excecao com uma mensagem descritiva.
     * @param mensagem Texto explicando o motivo do erro.
     */
    RecursoEsgotadoException(const string &mensagem) : ExcecaoJogo(mensagem) {}
};

/**
 * @brief Lancada quando o jogador nao tem ouro suficiente para comprar um item na loja.
 */
class SemDinheiroException : public ExcecaoJogo{
public:
    /**
     * @brief Constroi a excecao com uma mensagem descritiva.
     * @param mensagem Texto explicando o motivo do erro.
     */
    SemDinheiroException(const string &mensagem) : ExcecaoJogo(mensagem) {}
};

/**
 * @brief Lancada quando se tenta adicionar mais jogadores do que o grupo permite.
 */
class LimiteJogadoresException : public ExcecaoJogo{
public:
    /**
     * @brief Constroi a excecao com uma mensagem descritiva.
     * @param mensagem Texto explicando o motivo do erro.
     */
    LimiteJogadoresException(const string &mensagem) : ExcecaoJogo(mensagem) {}
};

/**
 * @brief Lancada para qualquer acao invalida do jogador.
 *
 * Exemplos: sem mana suficiente para usar habilidade, opcao de menu invalida,
 * ou pedir para criar um item que a classe nao sabe fabricar.
 */
class AcaoInvalidaException : public ExcecaoJogo{
public:
    /**
     * @brief Constroi a excecao com uma mensagem descritiva.
     * @param mensagem Texto explicando o motivo do erro.
     */
    AcaoInvalidaException(const string &mensagem) : ExcecaoJogo(mensagem) {}
};

#endif
